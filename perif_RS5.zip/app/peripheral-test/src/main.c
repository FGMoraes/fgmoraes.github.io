/*
 * Research group: GAPH-PUCRS  --  Fernando Gehm Moraes - Jan/2025
 *
 * Simple peripheral example
 */
#include <stdio.h>
#include "../include/periph.h"

void extern config_intr(void);

int main()
{
    int periph_data = 0;
    int a, b = 0;
    config_intr(); // Habilitar interrupção RS5

    for (int i = 0; i < 10; i++)
    {
        a = i*3;
        b = i*5;
        set_operand_a(a);
        set_operand_b(b);
        clear_periph_ready();  // Limpa o semáforo (false)
        periph_start();        // Start no periférico

        while(!get_periph_ready());         // Aguarda o semáforo ser verdadeiro (true)
        periph_data = get_periph_data();    // Acessa o dado lido pela interrupção
        
        printf("a = %d , b = %d, Result: %d\n", a, b, periph_data);
    }
    
    return 0;
}
