#include "../include/periph.h"

#define PLIC_IRQ_ID (*((volatile unsigned int*)0x70200004))
#define PLIC_ACK    (*((volatile unsigned int*)0x70200004))
#define MEI 11

#define PERIPH 1

void extern config_intr(void);

void irq_mei_dispatcher()
{
    switch(PLIC_IRQ_ID){
        case PERIPH:
            periph_handler();
            PLIC_ACK = PERIPH; // Manda iack sinalizando fim do tratamento da interrupção
            break;
        default:
            break;
    }
    
}

void irq_dispatcher(int cause)
{
    switch(cause){     
        case MEI:
            irq_mei_dispatcher();
            break;
        default:
            // codigo para excessão
            break;
    }
}


void extern except_handler(){

    return;
}
