#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#include "../include/periph.h"

// Semaphore variables
uint32_t periph_data;
bool periph_ready = false;

void periph_handler(){
    periph_data = RESULT;   // resultado do periférico
    periph_stop();         // Baixar o start para não fazer outra soma
    periph_ready = true;   // Ativa semáforo indicando dado pronto
}

//////////////////////////////////////////
// Semaphore functions
/////////////////////////////////////////
bool get_periph_ready(){
    return periph_ready; 
}

void clear_periph_ready(){ 
    periph_ready = 0;
}


//////////////////////////////////////////
// Read and write in the peripheral
/////////////////////////////////////////
void set_operand_a(int val){
    OPA = val;
}

void set_operand_b(int val){
    OPB = val;
}

void periph_start(){
    START = 1;
}

void periph_stop(){
    START = 0;
}

int get_periph_data(){
    return periph_data;
}



