
/*
 * Research group: GAPH-PUCRS  --  Fernando Gehm Moraes - Jan/2025
 *
 * Simple peripheral example:  memory address and functions prototypes
 */

#define OPA     (*((volatile unsigned int*)0x90000000))
#define OPB     (*((volatile unsigned int*)0x90000100))
#define RESULT  (*((volatile unsigned int*)0x90000200))
#define START   (*((volatile unsigned int*)0x90000300))

void periph_handler();
bool get_periph_ready();
void clear_periph_ready();
void set_operand_a(int val);
void set_operand_b(int val);
void periph_start();
void periph_stop();
int get_periph_data();
int read_periph_result();
