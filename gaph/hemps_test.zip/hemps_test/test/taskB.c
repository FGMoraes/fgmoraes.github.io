#include <task.h>
#include <stdlib.h>
 
Message msg;
 
int main(){
	int i, j,t;
	Echo("task B started.");
	Echo(itoa(GetTick()));
 
	for(i=0;i<10;i++){
		Receive(&msg,taskA);
		Echo("mensagem recebida ");
		Echo(itoa(i));
	}
	Echo(itoa(GetTick()));
	Echo("task B finished.");
	exit();
}
