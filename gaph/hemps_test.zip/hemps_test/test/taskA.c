#include <task.h>				     // Biblioteca que contém as primitivas da HeMPS.
#include <stdlib.h>
 
Message msg;				        // Cria uma estrutura para as mensagens.

	        
int main(){
	int i, j,t;
	Echo("task A started.");	 // A função Echo() é usado como debug, pois...
	Echo(itoa(GetTick()));			// grava em um arquivo o seu conteudo.
 
	for(i=0;i<10;i++){
		msg.length = 30;		          // Seta o tamanho da mensagem.
		for(j=0;j<30;j++) msg.msg[j]=i;	  // Gera conteúdo da mensagem.
		Send(&msg,taskB);		         // Envia a mensagem criada para a Tarefa B.
		Echo("mensagem enviada ");
		Echo(itoa(i));
	}
	
	
	Echo(itoa(GetTick()));			     // A função GetTick() retorna o tempo em ciclos...
	Echo("task A finished.");			 // de clock do sistema.
	exit();				                 // Função exit() termina a tarefa.
}

