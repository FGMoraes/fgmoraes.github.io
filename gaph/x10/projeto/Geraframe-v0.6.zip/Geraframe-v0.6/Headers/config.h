/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Arquivo : config.h	
	Descri��o: cria e interpreta arquivos de configura��o	
	Vers�o Utilizada: 0.4
	�ltima Modfica��o: Ferlini 25/09/08 (inser��o da parte do JC)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int cria_config()
{
	//Arquivo
	ofstream config;
	
	config.open( "config.x10" , ios::out );
	if ( !config.is_open() ) {
		config.close();
		return (0);
	}
	
	config << "FILE_OUT	= <ex.: frames>"	<< endl;
	config << "BASE_OUT	= <HEXBIN/BIN/HEX>"	<< endl;
	config << "PRINT_AFTER	= <NO/OVERHEAD/PAYLOAD/FEC/ERRO/SCRAM>" << endl;
	config << "RAMB_OUT	= <YES/NO>"			<< endl;
	config << "ASSINATURA	= <YES/NO>"			<< endl;
	config << "TEST_SIGNAL	= <NULL/PRBS>"		<< endl;
	config << "FEC			= <YES/NO>"			<< endl;
	config << "NUMERRORS	= <0,1,2,...128>"	<< endl;
	config << "TIPERRORS	= <RANDOM/RAJADA>"	<< endl;
	config << "ALIGNMENT	= <0,1,2,...>" 		<< endl;
	config << "SCRAMBLING	= <YES/NO>"			<< endl;
	config << "FAS			= <YES/NO>"			<< endl;
	config << "MFAS		= <YES/NO>"			<< endl;
	config << "SM_TTI		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "SM_BIP8		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>"			<< endl;
	config << "SM_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "GCC0		= <NO/ex.: #### #### #### ... #### [0..255 hex 2 bytes]>" 		<< endl;
	config << "RES1		= <NO/ex.: #### #### #### ... #### [0..255 hex 2 bytes]>" 		<< endl;
	config << "RES2		= <NO/ex.: ###### ###### ... ###### [0..255 hex 3 bytes]>" 		<< endl;
	config << "TCM_ACT		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM6_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM6_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM6_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM5_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM5_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM5_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM4_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM4_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM4_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "FTFL		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM3_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM3_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM3_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM2_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM2_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM2_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM1_TTI	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM1_BIP8	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "TCM1_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "PM_TTI		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "PM_BIP8		= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "PM_ALARMS	= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "EXP			= <NO/ex.: #### #### #### ... #### [0..255 hex 2 bytes]>" 		<< endl;
	config << "GCC1		= <NO/ex.: #### #### #### ... #### [0..255 hex 2 bytes]>" 		<< endl;
	config << "GCC2		= <NO/ex.: #### #### #### ... #### [0..255 hex 2 bytes]>" 		<< endl;
	config << "APS_PCC		= <NO/ex.: ######## ######## ... ######## [0..255 hex 4 bytes]>"<< endl;
	config << "RES3		= <NO/ex.: ############ ############ ... ############ [0..255 hex 6 bytes]>" 	<< endl;
	config << "PSI			= <NO/ex.: ## ## ## ## ## ... ## [0..255 hex bytes]>" 			<< endl;
	config << "JUSTIF_CTRL	= <NO/RANDOM/EXAUSTIVO>"	<< endl;
	config.close();
	
	cout << endl << endl << "---> Criado arquivo de configuracao config.x10" << endl << endl;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Carrega arquivo de configura��o
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int carrega_config()
{
	char lixo[100], line[100], overhead[10];
	FILE * config;
	int i;
	
	config = fopen (arquivo_config , "r");
	if (!config){
		cout << endl << "Arquivo config.x10 n�o encontrado!" << endl;
		return 0;
	}

	while(!feof(config)){
		fscanf(config, "%s", overhead);
		fscanf(config, "%s", lixo);
		fscanf(config, "%s", line);
		
		// Nome do arquivo de saida
		if(!strcmp(overhead, "FILE_OUT")){
			strcpy(FILE_OUT,line);
		}
		// Base
		if(!strcmp(overhead, "BASE_OUT")){
			if(!strcmp(line, "HEXBIN")){
				BASE_OUT = 1;
			}else{
				if(!strcmp(line, "BIN")){
					BASE_OUT = 2;
				}else{
					BASE_OUT = 3;
				}
			}
		}
		// Impressao do quadro em modo estrutural
		if(!strcmp(overhead, "PRINT_AFTER")){
			if(!strcmp(line, "OVERHEAD"))	  PRINT_AFTER = 1;
			else if(!strcmp(line, "PAYLOAD")) PRINT_AFTER = 2;
			else if(!strcmp(line, "FEC")) PRINT_AFTER = 3;
			else if(!strcmp(line, "ERRO")) PRINT_AFTER = 4;
			else if(!strcmp(line, "SCRAM")) PRINT_AFTER = 5;			
			else{
				if(!strcmp(line, "NO")) PRINT_AFTER = 0;
				else PRINT_AFTER = -1;
			}
		}
		// Gerar arquivos de inicializa��o para RAMBs 16x1024
		if(!strcmp(overhead, "RAMB_OUT")){
			if(!strcmp(line, "YES")){
				RAMB_OUT = 1;
			}else{
				RAMB_OUT = 0;
			}
		}
		// Assinatura
		if(!strcmp(overhead, "ASSINATURA")){
			if(!strcmp(line, "YES")){
				ASSINATURA = 1;
			}else{
				ASSINATURA = 0;
			}
		}
		// Tipo do sinal de teste
		if(!strcmp(overhead, "TEST_SIGNAL")){
			if(!strcmp(line, "NULL")){
				TEST_SIGNAL = 1;
			}else{
				TEST_SIGNAL = 0;
			}
		}
		// FEC
		if(!strcmp(overhead, "FEC")){
			if(!strcmp(line, "YES")){
				FEC = 1;
			}else{
				FEC = 0;
			}
		}
		// Quantidade de erros inseridos no frame
		if(!strcmp(overhead, "NUMERRORS")){
			NUMERRORS = atoi(line);
		}
		// Modo de inser��o de erros
		if(!strcmp(overhead, "TIPERRORS")){
			if(!strcmp(line, "RANDOM")){
				TIPERRORS = 1;
			}else{
				TIPERRORS = 0;
			}
		}
		// Quantidade de bits de desalinhamento
		if(!strcmp(overhead, "ALIGNMENT")){
			ALIGNMENT = atoi(line);
		}
		// Embaralhamento do sinal
		if(!strcmp(overhead, "SCRAMBLING")){
			if(!strcmp(line, "YES")){
				SCRAMBLING = 1;
			}else{
				SCRAMBLING = 0;
			}
		}
		/*
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		ALIGNMENT OVERHEADS
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		*/
		// FAS - Frame Alignment Signal
		if(!strcmp(overhead, "FAS")){
			if(!strcmp(line, "YES")){
				FAS = 1;
			}else{
				FAS = 0;
			}
		}
		// MFAS - Multi Frame Alignment Signal
		if(!strcmp(overhead, "MFAS")){
			if(!strcmp(line, "YES")){
				MFAS = 1;
			}else{
				MFAS = 0;
			}
		}
		/*
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		OTU OVERHEADS
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		*/
		// SM TTI - Section Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "SM_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					SM_TTI[i][0] = '0';
					SM_TTI[i][1] = '0';
				}
			}else{
				SM_TTI[0][0] = line[0];
				SM_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					SM_TTI[i][0] = line[0];
					SM_TTI[i][1] = line[1];
				}
			}			
		}
		// SM BIP8 - Section Monitoring - Bit Interlevead Parity
		if(!strcmp(overhead, "SM_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					SM_BIP8[i][0] = '0';
					SM_BIP8[i][1] = '0';
				}
			}else{
				SM_BIP8[0][0] = line[0];
				SM_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					SM_BIP8[i][0] = line[0];
					SM_BIP8[i][1] = line[1];
				}
			}
		}
		// SM ALARMS - Section Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	IAE - Incoming Alignment Error
		//	RES - Reservado
		if(!strcmp(overhead, "SM_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					SM_ALARMS[i][0] = '0';
					SM_ALARMS[i][1] = '0';
				}
			}else{
				SM_ALARMS[0][0] = line[0];
				SM_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					SM_ALARMS[i][0] = line[0];
					SM_ALARMS[i][1] = line[1];
				}
			}
		}
		// GCC0 - Global Communication Channel 0
		if(!strcmp(overhead, "GCC0")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					GCC0[i][0] = '0';
					GCC0[i][1] = '0';
					GCC0[i][2] = '0';
					GCC0[i][3] = '0';
				}
			}else{
				GCC0[0][0] = line[0];
				GCC0[0][1] = line[1];
				GCC0[0][2] = line[2];
				GCC0[0][3] = line[3];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					GCC0[i][0] = line[0];
					GCC0[i][1] = line[1];
					GCC0[i][2] = line[2];
					GCC0[i][3] = line[3];
				}
			}
		}
		// RES - Reservado para futura padronizacao internacional
		if(!strcmp(overhead, "RES1")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					RES1[i][0] = '0';
					RES1[i][1] = '0';
					RES1[i][2] = '0';
					RES1[i][3] = '0';
				}
			}else{
				RES1[0][0] = line[0];
				RES1[0][1] = line[1];
				RES1[0][2] = line[2];
				RES1[0][3] = line[3];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					RES1[i][0] = line[0];
					RES1[i][1] = line[1];
					RES1[i][2] = line[2];
					RES1[i][3] = line[3];
				}
			}
		}
		/*
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		ODU OVERHEADS
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		*/
		// RES - Reservado para futura padronizacao internacional
		if(!strcmp(overhead, "RES2")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					RES2[i][0] = '0';
					RES2[i][1] = '0';
					RES2[i][2] = '0';
					RES2[i][3] = '0';
					RES2[i][4] = '0';
					RES2[i][5] = '0';
				}
			}else{
				RES2[0][0] = line[0];
				RES2[0][1] = line[1];
				RES2[0][2] = line[2];
				RES2[0][3] = line[3];
				RES2[0][4] = line[4];
				RES2[0][5] = line[5];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					RES2[i][0] = line[0];
					RES2[i][1] = line[1];
					RES2[i][2] = line[2];
					RES2[i][3] = line[3];
					RES2[i][4] = line[4];
					RES2[i][5] = line[5];
				}
			}
		}
		// TCM ACT - Tandem Connection Monitoring Activation/Deactivation
		if(!strcmp(overhead, "TCM_ACT")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM_ACT[i][0] = '0';
					TCM_ACT[i][1] = '0';
				}
			}else{
				TCM_ACT[0][0] = line[0];
				TCM_ACT[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM_ACT[i][0] = line[0];
					TCM_ACT[i][1] = line[1];
				}
			}
		}
		// TCM6 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM6_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM6_TTI[i][0] = '0';
					TCM6_TTI[i][1] = '0';
				}
			}else{
				TCM6_TTI[0][0] = line[0];
				TCM6_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM6_TTI[i][0] = line[0];
					TCM6_TTI[i][1] = line[1];
				}
			}
		}
		// TCM6 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM6_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM6_BIP8[i][0] = '0';
					TCM6_BIP8[i][1] = '0';
				}
			}else{
				TCM6_BIP8[0][0] = line[0];
				TCM6_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM6_BIP8[i][0] = line[0];
					TCM6_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM6 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM6_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM6_ALARMS[i][0] = '0';
					TCM6_ALARMS[i][1] = '0';
				}
			}else{
				TCM6_ALARMS[0][0] = line[0];
				TCM6_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM6_ALARMS[i][0] = line[0];
					TCM6_ALARMS[i][1] = line[1];
				}
			}
		}
		// TCM5 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM5_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM5_ALARMS[i][0] = '0';
					TCM5_ALARMS[i][1] = '0';
				}
			}else{
				TCM5_TTI[0][0] = line[0];
				TCM5_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM5_TTI[i][0] = line[0];
					TCM5_TTI[i][1] = line[1];
				}
			}
		}
		// TCM5 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM5_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM5_BIP8[i][0] = '0';
					TCM5_BIP8[i][1] = '0';
				}
			}else{
				TCM5_BIP8[0][0] = line[0];
				TCM5_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM5_BIP8[i][0] = line[0];
					TCM5_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM5 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM5_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM5_ALARMS[i][0] = '0';
					TCM5_ALARMS[i][1] = '0';
				}
			}else{
				TCM5_ALARMS[0][0] = line[0];
				TCM5_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM5_ALARMS[i][0] = line[0];
					TCM5_ALARMS[i][1] = line[1];
				}
			}
		}
		// TCM4 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM4_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM4_ALARMS[i][0] = '0';
					TCM4_ALARMS[i][1] = '0';
				}
			}else{
				TCM4_TTI[0][0] = line[0];
				TCM4_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM4_TTI[i][0] = line[0];
					TCM4_TTI[i][1] = line[1];
				}
			}
		}
		// TCM4 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM4_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM4_BIP8[i][0] = '0';
					TCM4_BIP8[i][1] = '0';
				}
			}else{
				TCM4_BIP8[0][0] = line[0];
				TCM4_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM4_BIP8[i][0] = line[0];
					TCM4_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM4 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM4_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM4_ALARMS[i][0] = '0';
					TCM4_ALARMS[i][1] = '0';
				}
			}else{
				TCM4_ALARMS[0][0] = line[0];
				TCM4_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM4_ALARMS[i][0] = line[0];
					TCM4_ALARMS[i][1] = line[1];
				}
			}
		}
		// TCM3 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM3_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM3_ALARMS[i][0] = '0';
					TCM3_ALARMS[i][1] = '0';
				}
			}else{
				TCM3_TTI[0][0] = line[0];
				TCM3_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM3_TTI[i][0] = line[0];
					TCM3_TTI[i][1] = line[1];
				}
			}
		}
		// TCM3 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM3_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM3_BIP8[i][0] = '0';
					TCM3_BIP8[i][1] = '0';
				}
			}else{
				TCM3_BIP8[0][0] = line[0];
				TCM3_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM3_BIP8[i][0] = line[0];
					TCM3_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM3 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM3_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM3_ALARMS[i][0] = '0';
					TCM3_ALARMS[i][1] = '0';
				}
			}else{
				TCM3_ALARMS[0][0] = line[0];
				TCM3_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM3_ALARMS[i][0] = line[0];
					TCM3_ALARMS[i][1] = line[1];
				}
			}
		}
		// TCM2 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM2_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM2_ALARMS[i][0] = '0';
					TCM2_ALARMS[i][1] = '0';
				}
			}else{
				TCM2_TTI[0][0] = line[0];
				TCM2_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM2_TTI[i][0] = line[0];
					TCM2_TTI[i][1] = line[1];
				}
			}
		}
		// TCM2 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM2_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM2_BIP8[i][0] = '0';
					TCM2_BIP8[i][1] = '0';
				}
			}else{
				TCM2_BIP8[0][0] = line[0];
				TCM2_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM2_BIP8[i][0] = line[0];
					TCM2_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM2 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM2_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM2_ALARMS[i][0] = '0';
					TCM2_ALARMS[i][1] = '0';
				}
			}else{
				TCM2_ALARMS[0][0] = line[0];
				TCM2_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM2_ALARMS[i][0] = line[0];
					TCM2_ALARMS[i][1] = line[1];
				}
			}
		}
		// TCM1 TTI - Tandem Connection Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "TCM1_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM1_ALARMS[i][0] = '0';
					TCM1_ALARMS[i][1] = '0';
				}
			}else{
				TCM1_TTI[0][0] = line[0];
				TCM1_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM1_TTI[i][0] = line[0];
					TCM1_TTI[i][1] = line[1];
				}
			}
		}
		// TCM1 BIP8 - Tandem Connection Monitoring - Bit Interleaved Parity
		if(!strcmp(overhead, "TCM1_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM1_BIP8[i][0] = '0';
					TCM1_BIP8[i][1] = '0';
				}
			}else{
				TCM1_BIP8[0][0] = line[0];
				TCM1_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM1_BIP8[i][0] = line[0];
					TCM1_BIP8[i][1] = line[1];
				}
			}
		}
		// TCM1 ALARMS - Tandem Connection Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	STATUS - Status bits
		if(!strcmp(overhead, "TCM1_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					TCM1_ALARMS[i][0] = '0';
					TCM1_ALARMS[i][1] = '0';
				}
			}else{
				TCM1_ALARMS[0][0] = line[0];
				TCM1_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					TCM1_ALARMS[i][0] = line[0];
					TCM1_ALARMS[i][1] = line[1];
				}
			}
		}
		// FTFL - Fault Type and Fault Location
		if(!strcmp(overhead, "FTFL")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					FTFL[i][0] = '0';
					FTFL[i][1] = '0';
				}
			}else{
				FTFL[0][0] = line[0];
				FTFL[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					FTFL[i][0] = line[0];
					FTFL[i][1] = line[1];
				}
			}
		}
		// PM TTI - Path Monitoring - Tail Trace Identifier
		if(!strcmp(overhead, "PM_TTI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					PM_TTI[i][0] = '0';
					PM_TTI[i][1] = '0';
				}
			}else{
				PM_TTI[0][0] = line[0];
				PM_TTI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					PM_TTI[i][0] = line[0];
					PM_TTI[i][1] = line[1];
				}
			}
		}
		// PM BIP8 - Path Monitoring  - Bit Interleaved Parity
		if(!strcmp(overhead, "PM_BIP8")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					PM_BIP8[i][0] = '0';
					PM_BIP8[i][1] = '0';
				}
			}else{
				PM_BIP8[0][0] = line[0];
				PM_BIP8[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					PM_BIP8[i][0] = line[0];
					PM_BIP8[i][1] = line[1];
				}
			}
		}
		// PM ALARMS - Path Monitoring
		//	BDI - Backward Defect Indication
		//	BEI - Backward Error Indication
		//	BIAE - Backward Incoming Alignment Error
		//	IAE - Incoming Alignment Error
		//	RES - Reservado
		if(!strcmp(overhead, "PM_ALARMS")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					PM_ALARMS[i][0] = '0';
					PM_ALARMS[i][1] = '0';
				}
			}else{
				PM_ALARMS[0][0] = line[0];
				PM_ALARMS[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					PM_ALARMS[i][0] = line[0];
					PM_ALARMS[i][1] = line[1];
				}
			}
		}
		// EXP - Experimental
		if(!strcmp(overhead, "EXP")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					EXP[i][0] = '0';
					EXP[i][1] = '0';
					EXP[i][2] = '0';
					EXP[i][3] = '0';
				}
			}else{
				EXP[0][0] = line[0];
				EXP[0][1] = line[1];
				EXP[0][2] = line[2];
				EXP[0][3] = line[3];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					EXP[i][0] = line[0];
					EXP[i][1] = line[1];
					EXP[i][2] = line[2];
					EXP[i][3] = line[3];
				}
			}
		}
		// GCC1 - Global Communication Channel
		if(!strcmp(overhead, "GCC1")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					GCC1[i][0] = '0';
					GCC1[i][1] = '0';
					GCC1[i][2] = '0';
					GCC1[i][3] = '0';
				}
			}else{
				GCC1[0][0] = line[0];
				GCC1[0][1] = line[1];
				GCC1[0][2] = line[2];
				GCC1[0][3] = line[3];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					GCC1[i][0] = line[0];
					GCC1[i][1] = line[1];
					GCC1[i][2] = line[2];
					GCC1[i][3] = line[3];
				}
			}
		}
		// GCC2 - Global Communication Channel
		if(!strcmp(overhead, "GCC2")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					GCC2[i][0] = '0';
					GCC2[i][1] = '0';
					GCC2[i][2] = '0';
					GCC2[i][3] = '0';
				}
			}else{
				GCC2[0][0] = line[0];
				GCC2[0][1] = line[1];
				GCC2[0][2] = line[2];
				GCC2[0][3] = line[3];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					GCC2[i][0] = line[0];
					GCC2[i][1] = line[1];
					GCC2[i][2] = line[2];
					GCC2[i][3] = line[3];
				}
			}
		}
		// APS PCC - Automatic Protection Switching and Protection Communication Channel
		if(!strcmp(overhead, "APS_PCC")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					APS_PCC[i][0] = '0';
					APS_PCC[i][1] = '0';
					APS_PCC[i][2] = '0';
					APS_PCC[i][3] = '0';
					APS_PCC[i][4] = '0';
					APS_PCC[i][5] = '0';
					APS_PCC[i][6] = '0';
					APS_PCC[i][7] = '0';
				}
			}else{
				APS_PCC[0][0] = line[0];
				APS_PCC[0][1] = line[1];
				APS_PCC[0][2] = line[2];
				APS_PCC[0][3] = line[3];
				APS_PCC[0][4] = line[4];
				APS_PCC[0][5] = line[5];
				APS_PCC[0][6] = line[6];
				APS_PCC[0][7] = line[7];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					APS_PCC[i][0] = line[0];
					APS_PCC[i][1] = line[1];
					APS_PCC[i][2] = line[2];
					APS_PCC[i][3] = line[3];
					APS_PCC[i][4] = line[4];
					APS_PCC[i][5] = line[5];
					APS_PCC[i][6] = line[6];
					APS_PCC[i][7] = line[7];
				}
			}
		}
		// RES3 - Reservado
		if(!strcmp(overhead, "RES3")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					RES3[i][0] = '0';
					RES3[i][1] = '0';
					RES3[i][2] = '0';
					RES3[i][3] = '0';
					RES3[i][4] = '0';
					RES3[i][5] = '0';
					RES3[i][6] = '0';
					RES3[i][7] = '0';
					RES3[i][8] = '0';
					RES3[i][9] = '0';
					RES3[i][10] = '0';
					RES3[i][11] = '0';
				}
			}else{
				RES3[0][0] = line[0];
				RES3[0][1] = line[1];
				RES3[0][2] = line[2];
				RES3[0][3] = line[3];
				RES3[0][4] = line[4];
				RES3[0][5] = line[5];
				RES3[0][6] = line[6];
				RES3[0][7] = line[7];
				RES3[0][8] = line[8];
				RES3[0][9] = line[9];
				RES3[0][10] = line[10];
				RES3[0][11] = line[11];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					RES3[i][0] = line[0];
					RES3[i][1] = line[1];
					RES3[i][2] = line[2];
					RES3[i][3] = line[3];
					RES3[i][4] = line[4];
					RES3[i][5] = line[5];
					RES3[i][6] = line[6];
					RES3[i][7] = line[7];
					RES3[i][8] = line[8];
					RES3[i][9] = line[9];
					RES3[i][10] = line[10];
					RES3[i][11] = line[11];
				}
			}
		}
		/*
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		OPU OVERHEADS
		+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		*/
		//PSI - Payload Structure Identifier
		if(!strcmp(overhead, "PSI")){
			if(!strcmp(line, "NO")){
				for(i = 0; i < 256; i++){
					PSI[i][0] = '0';
					PSI[i][1] = '0';
				}
			}else{
				PSI[0][0] = line[0];
				PSI[0][1] = line[1];
				for(i = 1; i < 256; i++){
					fscanf(config, "%s", line);
					PSI[i][0] = line[0];
					PSI[i][1] = line[1];
				}
			}
		}
		//JC - Justification Control
		if(!strcmp(overhead, "JUSTIF_GEN")){
			if(!strcmp(line, "RANDOM")){
				JUSTIFICATION = 1;
			}else if(!strcmp(line, "EXAUSTIVO")){
				JUSTIFICATION = 2;
			}else{
				JUSTIFICATION = 0;
			} 
		}
	}
	
	fclose(config);
	//config.close();
}
