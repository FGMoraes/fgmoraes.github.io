// Fun��es Utilizadas
void print_interface(char *op[], int n_prints);
void void_interface(int n);
int  int_interface(int n);
char str_interface(int n);
void interface_principal(void);
void interface_final(bool *entrada, bool *continua);
void report_geral(void);

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime vetor de ponteiros para strings
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void print_interface(char *op[], int n_prints){
	int n = n_prints;
	while(*op && n--) cout << *op++;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime Interface sem ler do teclado
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void void_interface(int n){
	print_interface(menu_str,n);
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime Interface e l� um inteiro do teclado
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int int_interface(int n){
	int input;
	print_interface(menu_str,n);
	cin >> input;
	return input;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime Interface e l� uma string do teclado (nao foi testado)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char str_interface(int n){
	char input[50];
	print_interface(menu_str,n);
	cin >> input;
	return *input;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Interface Principal - Menu
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void interface_principal(void){
	int op;

	if(flagcf==0)
	{
		menu_str[0] = "\n---> Arquivo de Configura��o (valor em inteiro)\n";
		menu_str[1] = "\n       [1] Carregar arquivo de configura��o\n";
		menu_str[2] = "\n       [2] Criar arquivo de configura��o: ";
		do{ op = int_interface(3); }while((op!=1)&&(op!=2));
		ut_config = op;

		if(ut_config == 1){
			cout << endl <<"---> Nome do arquivo de configracao(ex.: config.x10): ";
			cin >> arquivo_config;
		}
		flagcf=1;
	}
	
	if(flagqf==0)
	{
		menu_str[0] = "\n---> Quantidade de frames a serem gerados (valor em inteiro): ";
		do{ op = int_interface(1); }while(op<0);
		qt_frames = op;
		flagqf=1;
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Interface Final
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void interface_final(bool *entrada, bool *continua){
	int op;

	*continua = *entrada = false;

	//Continua?
	menu_str[0] = "\n---> Deseja gerar mais frames?";
	menu_str[1] = "\n----- [1] (SIM)";
	menu_str[2] = "\n----- [2] (NAO): ";
	do{ op = int_interface(3); }while((op != 1)&&(op != 2));
	if(op==1){
		*continua = true;
		report_geral();
		menu_str[0] = "\n---> Deseja manter a configuracao acima?";
		menu_str[1] = "\n----- [1] (SIM)";
		menu_str[2] = "\n----- [2] (NAO): ";
		do{	op = int_interface(3); }while((op != 1)&&(op != 2));
		if(op==2) *entrada = true;
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime as opcoes escolhidas - Report
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void report_geral(void){
	
	cout << endl << endl << "::: Relat�rio :::" << endl;
	
	cout << endl << "--> Arquivo de Config.: " << arquivo_config;
	
	cout << endl << "--> Arquivo dos Frames: "   << FILE_OUT <<
			endl << "--> Base(s) Gerada(s):\t";
	switch(BASE_OUT){
			case 1: cout << "BIN/HEX"; break;
			case 2:	cout << "BIN	"; break;
			case 3: cout << "HEX    "; break;
			default:cout << "--//-- "; break;
	}

	cout <<	endl << "--> Ger. Quadro ap�s: \t";
	switch(PRINT_AFTER){
		case 1: cout << "OVERHEAD"; break;
		case 2: cout << "PAYLOAD"; break;
		case 3: cout << "FEC"; break;
		case 4: cout << "ERROS"; break;
		case 5: cout << "SCRAMBLER"; break;
		case 0: cout << "N�o"; break;
		default: break;
	}
		
	cout << endl << "--> Qtd. de Frames: \t"    << qt_frames <<
			endl << "--> Sinal de Teste: \t";
	switch(TEST_SIGNAL){
		case 1: cout << "NULL"; break;
		case 0: cout << "PRBS"; break;
		default: break;
	}
	
	cout <<	endl << "--> Inser��o de FAS: \t";
	switch(FAS){
		case 1: cout << "Sim"; break;
		case 0: cout << "N�o"; break;
		default: break;
	}

	cout <<	endl << "--> Inser��o de MFAS: \t";
	switch(MFAS){
		case 1: cout << "Sim"; break;
		case 0: cout << "N�o"; break;
		default: break;
	}
	
	cout << endl << "--> Scrambling:  \t";
	switch(SCRAMBLING){
		case 1: cout << "Sim"; break;
		case 0: cout << "Nao"; break;
		default: break;
	}

	cout <<	endl << "--> Assinatura:  \t";
	switch(ASSINATURA){
			case 1: cout << "Sim"; break;
			case 0: cout << "Nao"; break;
			default: break;
	}

	cout <<	endl << "--> Desalinhamento: \t" << ALIGNMENT <<
			endl << "--> Correcao (FEC): \t";
	switch(FEC){
		case 1: cout << "Sim"; break;
		case 0: cout << "Nao"; break;
		default: break;
	}		
	
	cout <<	endl << "--> Erros Inseridos: \t"<< NUMERRORS <<
			endl << "--> Modo de Erro: \t";
	switch(TIPERRORS){
		case 1: cout << "Aleatorio"; break;
		case 0: cout << "Rajada"   ; break;
		default:cout << "--//--"   ; break;
	}

	cout <<	endl << "--> Ger.Justificativa: \t";
	switch(JUSTIFICATION){
		case 1: cout << "Aleatoria"; break;
		case 2: cout << "Exaustiva"; break;
		case 0: cout << "N�o"; break;
		default: break;
	}	
	
	cout <<	endl << "--> Template VHDL: \t";
	switch(RAMB_OUT){
		case 1: cout << "Sim"; break;
		case 0: cout << "N�o"; break;
		default: break;
	}
	
	cout << endl << endl << "ATEN��O: Os arquivos gerados s�o salvos em suas respectivas pastas:";
	cout << endl << "\t - Arquivos contendo os frames s�o salvos em '/FILE_OUT' no diret�-" << endl << 
					"rio corrente do gerador de frames.";
	if(ASSINATURA)
		cout << endl << "\t - Arquivos contendo as assinaturas s�o salvos em '/ASSINATURA_OUT'" << endl <<
						"no diret�rio corrente do gerador de frames.";
	if(RAMB_OUT)
		cout << endl << "\t - Arquivos com os m�dulos VHDL de mem�ria contendo partes do frame" << endl <<
						"juntamente com o m�dulo VHDL do gerador de frames para prototipa��o, script" << endl <<
						"e testbench para simula��o s�o salvos em '/RAMB_OUT' no diret�rio  corrente" << endl <<
						"do gerador de frames.";
	
	cout << endl << endl;
}
