/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Gera arquivo com m�dulo VHDL gerador de frames para prototipa��o
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_frameHandler_vhdl(int n_frame)
{
	char file_name[32];	
	int i, j;
	char str_temp[5][200];
	time_t rawtime;
	struct tm * timeinfo;
			
	// Abre o arquivo para escrita do template vhdl
	sprintf(file_name,"RAMB_OUT/x10_frameshandler.vhd");
	saida_vhdl.open(file_name, ios::out);
	
	if(!saida_vhdl.is_open()){
		saida_vhdl.close();
		cout << endl << "ERRO: Nao foi possivel gerar o m�dulo VHDL do gerador de frames!" << endl;
	}else{
		// Insere no arquivo o in�cio do m�dulo gerador de frames
		saida_vhdl << "--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n--	Grupo de Apoio ao Projeto de Hardware  - GAPH";
		saida_vhdl << "\n--	Projeto X10GiGA - FINEP/PUCRS/TERACOM";
		saida_vhdl << "\n-- ";
		saida_vhdl << "\n--	M�dulo:	Memoria - Gerador de Frames - Prototipa��o";
		saida_vhdl << "\n--	Autor:	Gerson Scartezzini";
		saida_vhdl << "\n--";
		
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );		
		strftime(str_temp[0],200,"\n--	M�dulo gerado em %d de %B de %Y �s %Hh%Mmin pelo",timeinfo);
		saida_vhdl << str_temp[0];
		
		saida_vhdl << "\n--	pelo programa gerador de frames OTN do projeto X10GiGA.";
		saida_vhdl << "\n--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\nlibrary IEEE;";
		saida_vhdl << "\nuse IEEE.std_logic_1164.all;";
		saida_vhdl << "\nuse IEEE.std_logic_unsigned.all;\n";

		saida_vhdl << "\nlibrary unisim;";
		saida_vhdl << "\nuse unisim.vcomponents.all;\n";


		saida_vhdl << "\nentity frameshandler is";
		saida_vhdl << "\nport(";
		saida_vhdl << "\n\tclk		: in  std_logic;					-- Entrada de clock";
		saida_vhdl << "\n\trst		: in  std_logic;					-- Entrada de reset";
		saida_vhdl << "\n\t-- Write";
		saida_vhdl << "\n\twe		: in  std_logic; 					-- Write enable";
		saida_vhdl << "\n\tdin		: in  std_logic_vector(63 downto 0);-- Entrada de dados";
		saida_vhdl << "\n\t--donew	: out std_logic;					-- Fim do armazenamento";
		saida_vhdl << "\n\t-- Read";
		saida_vhdl << "\n\tre		: in  std_logic; 					-- Read enable";
		saida_vhdl << "\n\tmem		: in  std_logic_vector(7  downto 0);-- Escolhe a mem�ria que ser� lida";
		saida_vhdl << "\n\taddr	: in  std_logic_vector(9  downto 0);-- Endere�o que ser� lido";
		saida_vhdl << "\n\tdouthi	: out std_logic_vector(31 downto 0);-- Sa�da de dados parte alta";
		saida_vhdl << "\n\tdoutlo	: out std_logic_vector(31 downto 0);-- Sa�da de dados parte baixa";
		saida_vhdl << "\n\tdoner	: out std_logic						-- Fim da leitura";
		saida_vhdl << "\n);";
		saida_vhdl << "\nend frameshandler;\n";

		saida_vhdl << "\narchitecture frameshandler of frameshandler is";
		
		saida_vhdl << "\n\n\tcomponent RAMB16_S18_S18 is";
		saida_vhdl << "\n\tport(";
		saida_vhdl << "\n\t\tDOA   : out std_logic_vector(15 downto 0);	-- Port A 16-bit Data Output";
		saida_vhdl << "\n\t\tDOB   : out std_logic_vector(15 downto 0); 	-- Port B 16-bit Data Output";
		saida_vhdl << "\n\t\tDOPA  : out std_logic_vector(1  downto 0);	-- Port A 2-bit Parity Output";
		saida_vhdl << "\n\t\tDOPB  : out std_logic_vector(1  downto 0);	-- Port B 2-bit Parity Output";
		saida_vhdl << "\n\t\tADDRA : in  std_logic_vector(9  downto 0); 	-- Port A 10-bit Address Input";
		saida_vhdl << "\n\t\tADDRB : in  std_logic_vector(9  downto 0); 	-- Port B 10-bit Address Input";
		saida_vhdl << "\n\t\tCLKA  : in  std_logic;			 			-- Port A Clock";
		saida_vhdl << "\n\t\tCLKB  : in  std_logic;			 			-- Port B Clock";
		saida_vhdl << "\n\t\tDIA   : in  std_logic_vector(15 downto 0); 	-- Port A 16-bit Data Input";
		saida_vhdl << "\n\t\tDIB   : in  std_logic_vector(15 downto 0); 	-- Port B 16-bit Data Input";
		saida_vhdl << "\n\t\tDIPA  : in  std_logic_vector(1  downto 0); 	-- Port A 2-bit parity Input";	
		saida_vhdl << "\n\t\tDIPB  : in  std_logic_vector(1  downto 0); 	-- Port-B 2-bit parity Input";
		saida_vhdl << "\n\t\tENA   : in  std_logic;			 			-- Port A RAM Enable Input";
		saida_vhdl << "\n\t\tENB   : in  std_logic;			 			-- Port B RAM Enable Input";
		saida_vhdl << "\n\t\tSSRA  : in  std_logic;			 			-- Port A Synchronous Set/Reset Input";
		saida_vhdl << "\n\t\tSSRB  : in  std_logic;			 			-- Port B Synchronous Set/Reset Input";
		saida_vhdl << "\n\t\tWEA   : in  std_logic;			 			-- Port A Write Enable Input";
		saida_vhdl << "\n\t\tWEB   : in  std_logic			 			-- Port B Write Enable Input";
		saida_vhdl << "\n\t);";
		saida_vhdl << "\n\tend component;\n";

		saida_vhdl << "\n\tsignal start		: std_logic;					-- Start da escrita";
		saida_vhdl << "\n\tsignal donewr		: std_logic:='0';					-- Sinal intermedi�rio do sinal que identifica o fim da escrita";
		saida_vhdl << "\n\tsignal addrw		: std_logic_vector(9 downto 0);	-- Sinal intermedi�rio dos endere�os para escrita (Porta A)";
		saida_vhdl << "\n\tsignal addre		: std_logic_vector(9 downto 0);	-- Sinal intermedi�rio dos endere�os para leitura (Porta B)";
		saida_vhdl << "\n\tsignal mems			: std_logic_vector(7 downto 0);	-- Sinal intermedi�rio da sele��o de mem�ria (leitura)";
		saida_vhdl << "\n\tsignal contram		: std_logic_vector(7 downto 0);	-- Sinal intermedi�rio da sele��o de mem�ria (escrita)";
		
		saida_vhdl << "\n\t-- Sinais das Block RAMs";
		for(i = 0; i < 2*n_frame; i++){
			sprintf(str_temp[0],"\n\tsignal do_mem%02d	: std_logic_vector(63 downto 0);	-- Sa�da de dados da mem�ria %02d",i,i);
			sprintf(str_temp[1],"\n\tsignal we_mem%02d	: std_logic;",i);
			saida_vhdl << str_temp[0] << str_temp[1];
		}
		
		// In�cio do gerador
		saida_vhdl << "\nbegin\n";

		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n\t-- Write Process";
		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n\tprocess(clk, rst, we)";
		saida_vhdl << "\n\tbegin";
		saida_vhdl << "\n\t\tif we = '0' or rst='1' then";
		saida_vhdl << "\n\t\t\taddrw   <= (others => '0');";
		saida_vhdl << "\n\t\t\tcontram <= (others => '0');";			
		
		for(i = 0; i < 2*n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\twe_mem%02d   <= '0';",i);
			saida_vhdl << str_temp[0];
		}

		saida_vhdl << "\n\t\telsif clk'event and clk = '1' then";
		saida_vhdl << "\n\t\t\tif donewr = '0' then";
		saida_vhdl << "\n\t\t\t\tcase contram is";
				
		for(i = 0; i < 2*n_frame; i++)
		{
			sprintf(str_temp[0],"\n\t\t\t\t\twhen x\"%02X\"	=>",i);
			saida_vhdl << str_temp[0];
			for(j = 0; j < 2*n_frame; j++)
			{
				if(i==j) sprintf(str_temp[0],"\n\t\t\t\t\t\t\twe_mem%02d   <= '1';",j);
				else sprintf(str_temp[0],"\n\t\t\t\t\t\t\twe_mem%02d   <= '0';",j);
				saida_vhdl << str_temp[0];
			}
			saida_vhdl << "\n\t\t\t\t\t\t\tdonewr	 <= '0';";
		}

		saida_vhdl << "\n\t\t\t\t\twhen others	=>";
		for(j = 0; j < 2*n_frame; j++)
		{
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\twe_mem%02d   <= '0';",j);
			saida_vhdl << str_temp[0];
		}
		saida_vhdl << "\n\t\t\t\t\t\t\tdonewr	 <= '1';";

		saida_vhdl << "\n\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\taddrw <= addrw + 1;";

		saida_vhdl << "\n\t\t\t\tif addrw = x\"3FE\" then";
		saida_vhdl << "\n\t\t\t\t\tcontram <= contram + 1;";
		saida_vhdl << "\n\t\t\t\tend if;";

		saida_vhdl << "\n\t\t\telse";
		saida_vhdl << "\n\t\t\t\taddrw <= (others => '0');";
		saida_vhdl << "\n\t\t\tend if;";
		saida_vhdl << "\n\t\tend if;";
		saida_vhdl << "\n\tend process;\n";
		
		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n\t-- Read Process";
		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		
		
		saida_vhdl << "\n\tprocess(clk, re)";
		saida_vhdl << "\n\tbegin";
		saida_vhdl << "\n\t\tif re = '0' then";
		saida_vhdl << "\n\t\t\tmems   <= (others => '0');";
		saida_vhdl << "\n\t\t\taddre  <= (others => '0');";
		saida_vhdl << "\n\t\t\tdouthi <= (others => '0');";
		saida_vhdl << "\n\t\t\tdoutlo <= (others => '0');";
		saida_vhdl << "\n\t\t\tdoner  <= '0';";
		saida_vhdl << "\n\t\telsif clk'event and clk = '1' then";
		saida_vhdl << "\n\t\t\taddre <= addr;";
		saida_vhdl << "\n\t\t\tmems  <= mem;";
		saida_vhdl << "\n\t\t\tcase mems is";	
			
		for(j = 0; j < 2*n_frame; j++)
		{
			sprintf(str_temp[0],"\n\t\t\t\twhen x\"%02X\"	=>  douthi <= do_mem%02d(63 downto 32);",j,j);
			sprintf(str_temp[1],"\n\t\t\t\t\t\t\t\tdoutlo <= do_mem%02d(31 downto  0);",j);
			
			saida_vhdl << str_temp[0] << str_temp[1];
			saida_vhdl << "\n\t\t\t\t\t\t\t\tdoner <= '0';";
		}
		
		saida_vhdl << "\n\t\t\t\twhen others =>  douthi <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tdoutlo <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tdoner <= '1';";
		
		saida_vhdl << "\n\t\t\tend case;";
		saida_vhdl << "\n\t\tend if;";
		saida_vhdl << "\n\tend process;\n";
		
		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n\t-- Mem�rias";
		saida_vhdl << "\n\t--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		
		for(i = 0; i < 2*n_frame; i++)
		{
			for(j = 0; j < 4; j++)
			{
				sprintf(str_temp[0],"\n\t-- MEM%02d_RAMB%02d instantiation",i,j);
				sprintf(str_temp[1],"\n\tMEM%02d_RAMB%02d : RAMB16_S18_S18",i,j);		
				saida_vhdl << str_temp[0] << str_temp[1];
				saida_vhdl << "\n\tport map (";
				saida_vhdl << "\n\t\tDOA   => open,";
				sprintf(str_temp[0],"\n\t\tDOB   => do_mem%02d(%d downto %d),-- Port 16-bit Data Output",i,((5-j-1)*16)-1,((5-j-1)*16)-16);		
				saida_vhdl << str_temp[0];
			    saida_vhdl << "\n\t\tDOPA  => open,";
			    saida_vhdl << "\n\t\tDOPB  => open,";
			    saida_vhdl << "\n\t\tADDRA => addrw,					-- Port 10-bit Address Input to Write";
			    saida_vhdl << "\n\t\tADDRB => addre,					-- Port 10-bit Address Input to Read";
			    saida_vhdl << "\n\t\tCLKA  => clk, 					-- Port A Clock";
			    saida_vhdl << "\n\t\tCLKB  => clk, 					-- Port B Clock";
				
				
				
				sprintf(str_temp[0],"\n\t\tDIA   => din(%d downto %d),		-- Port 16-bit Data Input",((5-j-1)*16)-1,((5-j-1)*16)-16);
				saida_vhdl << str_temp[0];
							
				
			    saida_vhdl << "\n\t\tDIB   => (others => '0'),";
			    saida_vhdl << "\n\t\tDIPA  => (others => '0'),";
			    saida_vhdl << "\n\t\tDIPB  => (others => '0'),";
			    saida_vhdl << "\n\t\tENA   => we,";
			    saida_vhdl << "\n\t\tENB   => re,";
			    saida_vhdl << "\n\t\tSSRA  => '0',";
			    saida_vhdl << "\n\t\tSSRB  => '0',";
				
				sprintf(str_temp[0],"\n\t\tWEA   => we_mem%02d,				-- Port Write Enable Input",i);		
				saida_vhdl << str_temp[0];

			    saida_vhdl << "\n\t\tWEB   => '0'";
				saida_vhdl << "\n\t);";
				sprintf(str_temp[0],"\n\t-- End of MEM%02d_RAMB%02d instantiation\n",i,j);
				saida_vhdl << str_temp[0];
			}
		}
		
		saida_vhdl << "\nend frameshandler;";
			
		saida_vhdl.close();
	}
}
