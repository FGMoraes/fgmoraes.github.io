// Fun��es Utilizadas
void insere_fec(void);
int bintodec(bool simb[8]);
int shift(bool simb[8]);
unsigned char dectoalfa(unsigned char dec);
unsigned char alfatodec(unsigned char alfa);
unsigned char mult(unsigned char a, unsigned char b);
unsigned char inv(unsigned char a);

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Insere FEC no frame
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void insere_fec(void)
{
	int i, j, k, l;
    unsigned char fec[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    unsigned char pol[16] = {59, 36, 50, 98, 229, 41, 65, 163, 8, 30, 209, 68, 189, 104, 13, 59};
    unsigned char feedback;

	for(i = 0; i < 4; i++){		
		cout << endl << "\t" << setw(3) << setfill('0') << (i*25) << "%\tConclu�do";
		for(j = 0; j < 16; j++){
			// Encoder Reed-Solom
			for(k = 0; k < 239; k++){
				feedback = frame[k+(255*i)][j] xor fec[15];
	            for(l = 15; l > 0; l--) fec[l] = mult(feedback,pol[l]) xor fec[l-1];
	            fec[0]=mult(feedback,pol[0]);
			}
			// Carrega a matriz do frame com as paridades
			for(k = 15; k >= 0; k--) frame[((255*(i+1))-1)-k][j] = fec[k];
			// Reseta o encoder
			for(k = 0; k < 16; k++) fec[k]=0;	
		}
	}
	cout << endl << "\r\t100%\tConclu�do";
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Recebe um vetor de 8 bits e transforma em decimal
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int bintodec(bool simb[8]){
    return simb[0]*128+simb[1]*64+simb[2]*32+simb[3]*16+
		   simb[4]*8+simb[5]*4+simb[6]*2+simb[7];
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Implementa um est�gio do LFSR para o polin�mio X^8+X^4+X^3+X^2+1
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int shift(bool simb[8]){
    bool aux;

    aux = simb[0];
    simb[0] = simb[1];
    simb[1] = simb[2];
    simb[2] = simb[3];
    simb[3] = simb[4] xor aux;
    simb[4] = simb[5] xor aux;
    simb[5] = simb[6] xor aux;
    simb[6] = simb[7];
    simb[7] = aux;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Recebe um decimal e retorna a pot�ncia de alfa
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
unsigned char dectoalfa(unsigned char dec){
    bool aux[8] = {0,0,0,0,0,0,0,1};
    unsigned char alfa = 0;

    if(dec == 0) alfa = 255;
    else{
        while(bintodec(aux) != dec){
            shift(aux);
            alfa++;
        }
    }

    return alfa;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Recebe uma pot�ncia de alfa e retorna o decimal corresponsdente
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
unsigned char alfatodec(unsigned char alfa){
    bool aux[8] = {0,0,0,0,0,0,0,1};
    int i, dec;

    if(alfa == 255) dec = 0;
    else{
        for(i = 0; i < alfa; i++) shift(aux);
        dec = bintodec(aux);
    }

    return dec;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Multiplica dois valores em decimal
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
unsigned char mult(unsigned char a, unsigned char b){
    unsigned char res;

    if(a == 0 || b == 0) res = 0;
    else res = alfatodec((dectoalfa(a) + dectoalfa(b))%255);

    return res;
}
