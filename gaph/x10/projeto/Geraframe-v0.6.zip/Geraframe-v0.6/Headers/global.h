/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Arquivo : global.h	
	Descri��o: declara��o das vari�veis globais	
	Vers�o Utilizada: 0.4
	�ltima Modfica��o: Ferlini 25/09/08 (inser��o da parte do JC)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/

// Tamanho do FAS e do Frame
#define TAMFAS          48
#define TAMLINHA		64
#define TAMFRAME        130560

// Frame
char frame[1020][16];

//Linha
char linha[TAMLINHA];
int  tam_linha;

//PRBS
long unsigned int seed = 1;

// Arquivos
ofstream saida_bin, saida_hex, saida, saida_assinatura, saida_quadro;
char arquivo_config[50];

// Arquivos com m�dulos VHDL de mem�ria contendo partes do frame
ofstream saida_ramb1, saida_ramb2, saida_ramb3, saida_ramb4, 
		 saida_ramb5, saida_ramb6, saida_ramb7, saida_ramb8;

// Arquivo com m�dulo VHDL gerador de frames para prototipacao 
ofstream saida_vhdl, saida_script, saida_tb;

// Main
int	 qt_frames;
int  ut_config;
char *menu_str[0];

// Argumentos da Main
int flagcf = 0; // Flag de Config File passado como parametro na chamada do programa
int flagqf = 0; // Flag de Quantidade de Frams passado como parametro na chamada do programa

// Config
char FILE_OUT[50];
int  RAMB_OUT;
int	 ASSINATURA;
int  TEST_SIGNAL;
int  BASE_OUT;
int  PRINT_AFTER;
int  FEC;
int  NUMERRORS;
int  TIPERRORS;
int  ALIGNMENT;
int  SCRAMBLING;
int  FAS;
int  MFAS;
int	 JUSTIFICATION;
char JC[3];
int  NJO,PJO;


char TCM_ACT[256][2];
char APS_PCC[256][8];
char FTFL[256][2];   
char EXP[256][4];
char PSI[256][2];

char SM_TTI[256][2];		char PM_TTI[256][2];   
char SM_BIP8[256][2];       char PM_BIP8[256][2];
char SM_ALARMS[256][2];     char PM_ALARMS[256][2];

char GCC0[256][4];			char RES1[256][4];
char GCC1[256][4];          char RES2[256][6];
char GCC2[256][4];          char RES3[256][12];

char TCM1_TTI[256][2];		char TCM2_TTI[256][2];		char TCM3_TTI[256][2];
char TCM1_BIP8[256][2];     char TCM2_BIP8[256][2];     char TCM3_BIP8[256][2];
char TCM1_ALARMS[256][2];   char TCM2_ALARMS[256][2];   char TCM3_ALARMS[256][2];

char TCM4_TTI[256][2];		char TCM5_TTI[256][2];		char TCM6_TTI[256][2];
char TCM4_BIP8[256][2];     char TCM5_BIP8[256][2];     char TCM6_BIP8[256][2];
char TCM4_ALARMS[256][2];   char TCM5_ALARMS[256][2];   char TCM6_ALARMS[256][2];

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	XOR - Operacao xor com variaveis do tipo char
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char xora (char a, char b)
{
	if (a != b)
	{
		return '1';
	}else{
		return '0';
	}
}
