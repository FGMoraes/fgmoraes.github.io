//Fun��es Utilizadas
void gera_posicao_erros(int num_erros, int mod_erro);
void insert_error_frame(int linha, int coluna);

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Insere erros no frame
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void insert_error_frame(int linha, int coluna){
	frame[linha][coluna] = 0;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Gera as posi��es de erro cuidando para se poss�vel corrig�-los e n�o afetar o FAS
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_posicao_erros(int num_erros, int mod_erro){
	int i,pos,x,y,cont;
	char err_cont[16]={8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8};

	srand(time(NULL));

	switch(mod_erro){
		case 1: // Insere em modo aleatorio
			cont = num_erros;
			while(cont){
				pos = rand()%16314 + 6;
				x = pos/16;
				y = pos%16;
				if(err_cont[y]){
					insert_error_frame(x,y);
					err_cont[y]--;
					cont--;
				}
			}break;
		case 0: // Insere em modo rajada
			pos = rand()%(16314-num_erros) + 6;
			x = pos/16;
			y = pos%16;
			cont = num_erros;
			while(cont){
				if(y==16){ x++; y=0;}
				insert_error_frame(x,y);
				y++;
				cont--;
			}break;
		default:
			break;
	}
}
