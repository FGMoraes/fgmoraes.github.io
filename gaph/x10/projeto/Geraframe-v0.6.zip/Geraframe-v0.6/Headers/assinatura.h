// Fun��es Utilizadas
int assinatura(char linha[64]);
char hexa(char bin[4]);

char D[64], Q[64];
char s1[4];

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Gerador de assinatura
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int assinatura(char linha[64])
{
	int i, k, m;

	D[0] = xora(linha[0],Q[63]);
	D[1] = xora(linha[1],Q[0]);
	D[2] = xora(xora(linha[2],Q[1]),Q[63]);
	D[3] = xora(xora(linha[3],Q[2]),Q[63]);

	for(i = 4; i < 64; i++)
	{
		D[i] = xora(linha[i],Q[i-1]);
	}

	for (k = 0; k < 64; k++){
		Q[k] = D[k];
	}

	for (m = 0; m < 64; m++){
		if ((m % 4) == 0)
		{
			for (k = 0; k < 4; k++)
			{
				s1[k] = Q[m+k];
				if (k==3) saida_assinatura << convert_bin2ascii(s1);
			}
		}
		if (m==63) saida_assinatura << endl;
	}
}
