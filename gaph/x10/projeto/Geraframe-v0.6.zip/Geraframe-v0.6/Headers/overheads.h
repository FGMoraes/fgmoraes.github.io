/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Insere overheads no frame
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void insere_overheads(int mframe)
{
	char aux[2];
	int i, tipo_jc, pos_jc;
	
	/*
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	ALIGNMENT OVERHEADS
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	*/
	// FAS
	if(FAS == 1){
		frame[0][0] = 0xF6;
		frame[0][1] = 0xF6;
		frame[0][2] = 0xF6;
		frame[0][3] = 0x28;
		frame[0][4] = 0x28;
		frame[0][5] = 0x28;
	}else{
		frame[0][0] = 0x00;
		frame[0][1] = 0x00;
		frame[0][2] = 0x00;
		frame[0][3] = 0x00;
		frame[0][4] = 0x00;
		frame[0][5] = 0x00;
	}
	//MFAS
	if(MFAS == 1){
		frame[0][6] = convert_int2hex(mframe);
	}else{
		frame[0][6] = 0x00;
	}
	/*
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	OTU OVERHEADS
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	*/
	//SM - TTI
	aux[0] = SM_TTI[mframe][0];
	aux[1] = SM_TTI[mframe][1];
	frame[0][7] = convert_ascii2hex(aux);
	//SM - BIP8
	aux[0] = SM_BIP8[mframe][0];
	aux[1] = SM_BIP8[mframe][1];
	frame[0][8] = convert_ascii2hex(aux);
	//SM - ALARMS
	aux[0] = SM_ALARMS[mframe][0];
	aux[1] = SM_ALARMS[mframe][1];
	frame[0][9] = convert_ascii2hex(aux);
	// GCC0
	aux[0] = GCC0[mframe][0];
	aux[1] = GCC0[mframe][1];
	frame[0][10] = convert_ascii2hex(aux);
	aux[0] = GCC0[mframe][2];
	aux[1] = GCC0[mframe][3];
	frame[0][11] = convert_ascii2hex(aux);
	// RES1
	aux[0] = RES1[mframe][0];
	aux[1] = RES1[mframe][1];
	frame[0][12] = convert_ascii2hex(aux);
	aux[0] = RES1[mframe][2];
	aux[1] = RES1[mframe][3];
	frame[0][13] = convert_ascii2hex(aux);
	// Mapping and Concatenation Specific (Ainda n�o usado)
	frame[0][14] = 0x00;
	frame[0][15] = 0x00;
	/*
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	ODU OVERHEADS
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	*/
	//RES2
	aux[0] = RES2[mframe][0];
	aux[1] = RES2[mframe][1];
	frame[255][0] = convert_ascii2hex(aux);
	aux[0] = RES2[mframe][2];
	aux[1] = RES2[mframe][3];
	frame[255][1] = convert_ascii2hex(aux);
	aux[0] = RES2[mframe][4];
	aux[1] = RES2[mframe][5];
	frame[255][2] = convert_ascii2hex(aux);
	//TCM ACT
	aux[0] = TCM_ACT[mframe][0];
	aux[1] = TCM_ACT[mframe][1];
	frame[255][3] = convert_ascii2hex(aux);
	//TCM6 - TTI
	aux[0] = TCM6_TTI[mframe][0];
	aux[1] = TCM6_TTI[mframe][1];
	frame[255][4] = convert_ascii2hex(aux);
	//TCM6 - BIP8
	aux[0] = TCM6_BIP8[mframe][0];
	aux[1] = TCM6_BIP8[mframe][1];
	frame[255][5] = convert_ascii2hex(aux);
	//TCM6 - ALARMS
	aux[0] = TCM6_ALARMS[mframe][0];
	aux[1] = TCM6_ALARMS[mframe][1];
	frame[255][6] = convert_ascii2hex(aux);
	//TCM5 - TTI
	aux[0] = TCM5_TTI[mframe][0];
	aux[1] = TCM5_TTI[mframe][1];
	frame[255][7] = convert_ascii2hex(aux);
	//TCM5 - BIP8
	aux[0] = TCM5_BIP8[mframe][0];
	aux[1] = TCM5_BIP8[mframe][1];
	frame[255][8] = convert_ascii2hex(aux);
	//TCM5 - ALARMS
	aux[0] = TCM5_ALARMS[mframe][0];
	aux[1] = TCM5_ALARMS[mframe][1];
	frame[255][9] = convert_ascii2hex(aux);
	//TCM4 - TTI
	aux[0] = TCM4_TTI[mframe][0];
	aux[1] = TCM4_TTI[mframe][1];
	frame[255][10] = convert_ascii2hex(aux);
	//TCM4 - BIP8
	aux[0] = TCM4_BIP8[mframe][0];
	aux[1] = TCM4_BIP8[mframe][1];
	frame[255][11] = convert_ascii2hex(aux);
	//TCM4 - ALARMS
	aux[0] = TCM4_ALARMS[mframe][0];
	aux[1] = TCM4_ALARMS[mframe][1];
	frame[255][12] = convert_ascii2hex(aux);
	// FTFL
	aux[0] = FTFL[mframe][0];
	aux[1] = FTFL[mframe][1];
	frame[255][13] = convert_ascii2hex(aux);
	// Mapping and Concatenation Specific (Ainda n�o usado)
	frame[255][14] = 0x00;
	frame[255][15] = 0x00;
	//TCM3 - TTI
	aux[0] = TCM3_TTI[mframe][0];
	aux[1] = TCM3_TTI[mframe][1];
	frame[510][0] = convert_ascii2hex(aux);
	//TCM3 - BIP8
	aux[0] = TCM3_BIP8[mframe][0];
	aux[1] = TCM3_BIP8[mframe][1];
	frame[510][1] = convert_ascii2hex(aux);
	//TCM3 - ALARMS
	aux[0] = TCM3_ALARMS[mframe][0];
	aux[1] = TCM3_ALARMS[mframe][1];
	frame[510][2] = convert_ascii2hex(aux);
	//TCM2 - TTI
	aux[0] = TCM2_TTI[mframe][0];
	aux[1] = TCM2_TTI[mframe][1];
	frame[510][3] = convert_ascii2hex(aux);
	//TCM2 - BIP8
	aux[0] = TCM2_BIP8[mframe][0];
	aux[1] = TCM2_BIP8[mframe][1];
	frame[510][4] = convert_ascii2hex(aux);
	//TCM2 - ALARMS
	aux[0] = TCM2_ALARMS[mframe][0];
	aux[1] = TCM2_ALARMS[mframe][1];
	frame[510][5] = convert_ascii2hex(aux);
	//TCM1 - TTI
	aux[0] = TCM1_TTI[mframe][0];
	aux[1] = TCM1_TTI[mframe][1];
	frame[510][6] = convert_ascii2hex(aux);
	//TCM1 - BIP8
	aux[0] = TCM1_BIP8[mframe][0];
	aux[1] = TCM1_BIP8[mframe][1];
	frame[510][7] = convert_ascii2hex(aux);
	//TCM1 - ALARMS
	aux[0] = TCM1_ALARMS[mframe][0];
	aux[1] = TCM1_ALARMS[mframe][1];
	frame[510][8] = convert_ascii2hex(aux);
	//PM - TTI
	aux[0] = PM_TTI[mframe][0];
	aux[1] = PM_TTI[mframe][1];
	frame[510][9] = convert_ascii2hex(aux);
	//PM - BIP8
	aux[0] = PM_BIP8[mframe][0];
	aux[1] = PM_BIP8[mframe][1];
	frame[510][10] = convert_ascii2hex(aux);
	//PM - ALARMS
	aux[0] = PM_ALARMS[mframe][0];
	aux[1] = PM_ALARMS[mframe][1];
	frame[510][11] = convert_ascii2hex(aux);
	//EXP
	aux[0] = EXP[mframe][0];
	aux[1] = EXP[mframe][1];
	frame[510][12] = convert_ascii2hex(aux);
	aux[0] = EXP[mframe][2];
	aux[1] = EXP[mframe][3];
	frame[510][13] = convert_ascii2hex(aux);
	// Mapping and Concatenation Specific (Ainda n�o usado)
	frame[510][14] = 0x00;
	frame[510][15] = 0x00;
	//GCC1
	aux[0] = GCC1[mframe][0];
	aux[1] = GCC1[mframe][1];
	frame[765][0] = convert_ascii2hex(aux);
	aux[0] = GCC1[mframe][2];
	aux[1] = GCC1[mframe][3];
	frame[765][1] = convert_ascii2hex(aux);
	//GCC2
	aux[0] = GCC2[mframe][0];
	aux[1] = GCC2[mframe][1];
	frame[765][2] = convert_ascii2hex(aux);
	aux[0] = GCC2[mframe][2];
	aux[1] = GCC2[mframe][3];
	frame[765][3] = convert_ascii2hex(aux);
	//APS_PCC
	aux[0] = APS_PCC[mframe][0];
	aux[1] = APS_PCC[mframe][1];
	frame[765][4] = convert_ascii2hex(aux);
	aux[0] = APS_PCC[mframe][2];
	aux[1] = APS_PCC[mframe][3];
	frame[765][5] = convert_ascii2hex(aux);
	aux[0] = APS_PCC[mframe][4];
	aux[1] = APS_PCC[mframe][5];
	frame[765][6] = convert_ascii2hex(aux);
	aux[0] = APS_PCC[mframe][6];
	aux[1] = APS_PCC[mframe][7];
	frame[765][7] = convert_ascii2hex(aux);
	//RES3
	aux[0] = RES3[mframe][0];
	aux[1] = RES3[mframe][1];
	frame[765][8] = convert_ascii2hex(aux);
	aux[0] = RES3[mframe][2];
	aux[1] = RES3[mframe][3];
	frame[765][9] = convert_ascii2hex(aux);
	aux[0] = RES3[mframe][4];
	aux[1] = RES3[mframe][5];
	frame[765][10] = convert_ascii2hex(aux);
	aux[0] = RES3[mframe][6];
	aux[1] = RES3[mframe][7];
	frame[765][11] = convert_ascii2hex(aux);
	aux[0] = RES3[mframe][8];
	aux[1] = RES3[mframe][9];
	frame[765][12] = convert_ascii2hex(aux);
	aux[0] = RES3[mframe][10];
	aux[1] = RES3[mframe][11];
	frame[765][13] = convert_ascii2hex(aux);
	/*
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	OPU OVERHEADS
	+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	*/
	//PSI
	if(mframe==0){ //Payload Type (somente no primeiro quadro dos 256)
		aux[0] = PSI[mframe][0];
		aux[1] = PSI[mframe][1];
		frame[765][14] = convert_ascii2hex(aux);
	}
	else frame[765][14] = 0x00; // Mapping and Concatenation Specific (Ainda n�o usado)
	frame[765][15] = 0x00;
	
	//JC - Justification Control
	if(JUSTIFICATION == 1){ //RANDOM
		tipo_jc = rand()%3 - 1;			
		if(tipo_jc == 1){ //Justificativa Postiva
			pos_jc = rand()%3;
			switch(pos_jc){
				case 0 : sprintf(JC,"%c%c%c",1,1,0); break;
				case 1 : sprintf(JC,"%c%c%c",1,0,1); break;
				case 2 : sprintf(JC,"%c%c%c",0,1,1); break;
				default: sprintf(JC,"%c%c%c",0,0,0); break;
			}
		}
		else if(tipo_jc == -1){ //Justificativa Negativa
			pos_jc = rand()%3;
			switch(pos_jc){
				case 0 : sprintf(JC,"%c%c%c",3,3,0); break;
				case 1 : sprintf(JC,"%c%c%c",3,0,3); break;
				case 2 : sprintf(JC,"%c%c%c",0,3,3); break;
				default: sprintf(JC,"%c%c%c",0,0,0); break;
			}
		}
		else // sem justificativa
			sprintf(JC,"%c%c%c",0,0,0);
	}	
	else if(JUSTIFICATION == 2){//EXAUSTIVO
		tipo_jc = mframe%60;
		//Caso em que ocorre 8 justificativas negativas, devendo voltar ao estado inicial
		if (tipo_jc>=0 && tipo_jc <8) sprintf(JC,"%c%c%c",1,1,0);
		//Caso em que ocorre 8 justificativas positivas, devendo voltar ao estado inicial
		else if (tipo_jc>=8 && tipo_jc <16)	sprintf(JC,"%c%c%c",3,3,0);			
		else{
			switch(tipo_jc){
				//Caso de anula��o, dado que ocorre uma justificativa negativa seguida de uma positiva
				case 16 : sprintf(JC,"%c%c%c",1,1,0); break;
				case 17 : sprintf(JC,"%c%c%c",3,3,0); break;
				//Caso de anula��o, dado que ocorre uma justificativa positiva seguida de uma negativa
				case 18 : sprintf(JC,"%c%c%c",3,3,0); break;
				case 19 : sprintf(JC,"%c%c%c",1,1,0); break;
				//Casos Espec�ficos
				case 20 : sprintf(JC,"%c%c%c",0,0,0); break;
				case 21 : sprintf(JC,"%c%c%c",1,1,3); break;
				case 22 : sprintf(JC,"%c%c%c",1,3,1); break;
				case 23 : sprintf(JC,"%c%c%c",3,1,1); break;
				case 24 : sprintf(JC,"%c%c%c",3,3,1); break;
				case 25 : sprintf(JC,"%c%c%c",3,1,3); break;
				case 26 : sprintf(JC,"%c%c%c",1,3,3); break;
				//Casos com valores inv�lidos
				case 27 : sprintf(JC,"%c%c%c",0,0,0); break;
				case 28 : sprintf(JC,"%c%c%c",0,0,2); break;
				case 29 : sprintf(JC,"%c%c%c",0,2,0); break;
				case 30 : sprintf(JC,"%c%c%c",2,0,0); break;
				case 31 : sprintf(JC,"%c%c%c",0,2,2); break;
				case 32 : sprintf(JC,"%c%c%c",2,0,2); break;
				case 33 : sprintf(JC,"%c%c%c",2,2,0); break;
				case 34 : sprintf(JC,"%c%c%c",2,2,2); break;
				case 35 : sprintf(JC,"%c%c%c",1,1,1); break;
				case 36 : sprintf(JC,"%c%c%c",1,1,2); break;
				case 37 : sprintf(JC,"%c%c%c",1,2,1); break;
				case 38 : sprintf(JC,"%c%c%c",2,1,1); break;
				case 39 : sprintf(JC,"%c%c%c",1,2,2); break;
				case 40 : sprintf(JC,"%c%c%c",2,1,2); break;
				case 41 : sprintf(JC,"%c%c%c",2,2,1); break;
				case 42 : sprintf(JC,"%c%c%c",2,2,2); break;
				case 43 : sprintf(JC,"%c%c%c",3,3,3); break;
				case 44 : sprintf(JC,"%c%c%c",3,3,2); break;
				case 45 : sprintf(JC,"%c%c%c",3,2,3); break;
				case 46 : sprintf(JC,"%c%c%c",2,3,3); break;
				case 47 : sprintf(JC,"%c%c%c",3,2,2); break;
				case 48 : sprintf(JC,"%c%c%c",2,3,2); break;
				case 49 : sprintf(JC,"%c%c%c",2,2,3); break;
				case 50 : sprintf(JC,"%c%c%c",2,2,2); break;
				default : sprintf(JC,"%c%c%c",0,0,0); break;
			}
		}
	}	
	
	if(JUSTIFICATION){
		frame[0][15] = JC[0];
		frame[255][15] = JC[1];
		frame[510][15] = JC[2];
		
		NJO = 0;
		PJO = 0;
		for(i=0;i<3;i++){
			if(JC[i]==1) NJO++;
			if(JC[i]==3) PJO++;
		}
	}
}
