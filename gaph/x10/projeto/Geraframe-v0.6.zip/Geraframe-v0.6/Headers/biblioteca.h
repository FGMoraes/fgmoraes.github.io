#ifndef LIBS_H
#define LIBS_H


// std
#include <stdio.h>
#include <stdlib.h>

#include <ctime>
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
#include <unistd.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <queue>
#include <bitset>

#include <sys/stat.h>
#include <sys/types.h>


using namespace std;
using std::queue;
using std::bitset;

#endif

