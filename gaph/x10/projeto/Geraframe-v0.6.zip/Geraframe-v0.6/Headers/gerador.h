/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Gera arquivo com m�dulo VHDL gerador de frames para prototipa��o
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_template_vhdl(int n_frame)
{
	char file_name[32];	
	int i, j;
	char str_temp[5][200];
	time_t rawtime;
	struct tm * timeinfo;
	
	mkdir("RAMB_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	
	// Abre o arquivo para escrita do template vhdl
	sprintf(file_name,"RAMB_OUT/x10_geraframes.vhd");
	saida_vhdl.open(file_name, ios::out);
	
	if(!saida_vhdl.is_open()){
		saida_vhdl.close();
		cout << endl << "ERRO: Nao foi possivel gerar o m�dulo VHDL do gerador de frames!" << endl;
	}else{
		// Insere no arquivo o in�cio do m�dulo gerador de frames
		saida_vhdl << "--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\n--	Grupo de Apoio ao Projeto de Hardware  - GAPH";
		saida_vhdl << "\n--	Projeto X10GiGA - FINEP/PUCRS/TERACOM";
		saida_vhdl << "\n-- ";
		saida_vhdl << "\n--	M�dulo:	Memoria - Gerador de Frames - Prototipa��o";
		saida_vhdl << "\n--	Autor:	Jeferson Camargo de Oliveira";
		saida_vhdl << "\n--	Modifica��es:	Gerson Scartezzini";
		saida_vhdl << "\n--";
		
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );		
		strftime(str_temp[0],200,"\n--	M�dulo gerado em %d de %B de %Y �s %Hh%Mmin pelo",timeinfo);
		saida_vhdl << str_temp[0];
		
		saida_vhdl << "\n--	pelo programa gerador de frames OTN do projeto X10GiGA.";
		saida_vhdl << "\n--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_vhdl << "\nlibrary IEEE;";
		saida_vhdl << "\nuse IEEE.std_logic_1164.all;";
		saida_vhdl << "\nuse IEEE.std_logic_unsigned.all;\n";
		saida_vhdl << "\nentity geraframes is";
		saida_vhdl << "\nport(";
		saida_vhdl << "\n	clk, rst	: in  std_logic;";
		saida_vhdl << "\n	saida		: out std_logic_vector(63 downto 0)";
		saida_vhdl << "\n);";
		saida_vhdl << "\nend entity;\n";
		saida_vhdl << "\narchitecture geraframes of geraframes is";
		saida_vhdl << "\n	signal counter		: std_logic_vector(10 downto 0);";
		saida_vhdl << "\n	signal counter_ram	: std_logic_vector(7  downto 0);";
		saida_vhdl << "\n	signal address		: std_logic_vector(9  downto 0);";
		saida_vhdl << "\n	signal conjunto		: std_logic;";
		saida_vhdl << "\n	signal start		: std_logic;";
		saida_vhdl << "\n	signal saida_i		: std_logic_vector(63 downto 0);";
		// Insere os sinais necess�rios para montagem das palavras de sa�da
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n	signal saida_a_%03d	: std_logic_vector(63 downto 0);",i);
			sprintf(str_temp[1],"\n	signal saida_b_%03d	: std_logic_vector(63 downto 0);",i);
			saida_vhdl << str_temp[0] << str_temp[1];
		}
		// In�cio do gerador
		saida_vhdl << "\nbegin\n";
		saida_vhdl << "\n\tsaida <= saida_i;\n";		
		saida_vhdl << "\n\tM0: process(clk)";
		saida_vhdl << "\n\tbegin";
		saida_vhdl << "\n\t\tif clk'event and clk = '1' then";
		saida_vhdl << "\n\t\t\tif rst = '1' then";
		saida_vhdl << "\n\t\t\t\tcounter     <= " << '"' << "00000000001" << '"' << ";";
		saida_vhdl << "\n\t\t\t\tcounter_ram <= (others => '0');";
		saida_vhdl << "\n\t\t\t\taddress     <= (others => '0');";
		saida_vhdl << "\n\t\t\t\tsaida_i     <= (others => '0');";
		saida_vhdl << "\n\t\t\t\tstart       <= '1';";
		saida_vhdl << "\n\t\t\t\tconjunto    <= '0';";
		saida_vhdl << "\n\t\t\telse";
		saida_vhdl << "\n\t\t\t\tcase counter is";
		saida_vhdl << "\n\t\t\t\t\twhen " << '"' << "11111111000" << '"' << "=>";
		saida_vhdl << "\n\t\t\t\t\t\tcounter <= " << '"' << "00000000001" << '"' << ";";
		saida_vhdl << "\n\t\t\t\t\t\taddress <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_b_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Continua��o do gerador
		saida_vhdl << "\n\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\twhen " << '"' << "00000000001" << '"' << "=>";
		saida_vhdl << "\n\t\t\t\t\t\tif start = '0' then";
		saida_vhdl << "\n\t\t\t\t\t\t\tcounter_ram <= counter_ram + 1;";
		saida_vhdl << "\n\t\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_b_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}		
		saida_vhdl << "\n\t\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\telse";
		saida_vhdl << "\n\t\t\t\t\t\t\tcounter_ram 	 <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\tsaida_i       <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\tend if;";
		saida_vhdl << "\n\t\t\t\t\t\taddress <= address + 1;";
		saida_vhdl << "\n\t\t\t\t\t\tcounter <= counter + 1;";
		saida_vhdl << "\n\t\t\t\t\twhen " << '"' << "00000000010" << '"' << "=>";		
		saida_vhdl << "\n\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_a_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Continua��o do gerador		
		saida_vhdl << "\n\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\tconjunto<= '0';";
		saida_vhdl << "\n\t\t\t\t\t\taddress <= address + 1;";
		saida_vhdl << "\n\t\t\t\t\t\tcounter <= counter + 1;";
		saida_vhdl << "\n\t\t\t\t\twhen others =>";
		saida_vhdl << "\n\t\t\t\t\t\tcase address is";
		saida_vhdl << "\n\t\t\t\t\t\t\twhen " << '"' << "1111111111" << '"' << "=>";				
		saida_vhdl << "\n\t\t\t\t\t\t\t\tstart	<= '0';";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tconjunto    <= '1';";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento	
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_a_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Continua��o do gerador
		saida_vhdl << "\n\t\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\t\twhen " << '"' << "0000000000" << '"' << "=>";				
		saida_vhdl << "\n\t\t\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_a_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Continua��o do gerador
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\t\twhen others =>";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tif conjunto = '0' then";
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_a_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Continua�� do gerador
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\t\t\telse";
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\tcase counter_ram is";
		// Gera c�digo de escolha da sa�da de acordo com o frame que est� sendo gerado no momento
		for(i = 0; i < n_frame; i++){
			sprintf(str_temp[0],"\n\t\t\t\t\t\t\t\t\t\twhen x%c%02X%c	=>  saida_i <= saida_b_%03d;",'"',i,'"',i);
			saida_vhdl << str_temp[0];
		}
		// Finalizando o gerador
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\t\twhen others =>	saida_i <= (others => '0');";
		saida_vhdl << "\n\t\t\t\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\t\t\tend if;";
		saida_vhdl << "\n\t\t\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\t\t\t\taddress <= address + 1;";
		saida_vhdl << "\n\t\t\t\t\t\tcounter <= counter + 1;";
		saida_vhdl << "\n\t\t\t\tend case;";
		saida_vhdl << "\n\t\t\tend if;";
		saida_vhdl << "\n\t\tend if;";
		saida_vhdl << "\n\tend process;\n";
			
		// Gera��o dos port maps das Block RAMs utilizadas

		saida_vhdl << "\n\t-- Instancia��o da BRAMS";
		sprintf(str_temp[1],"\n			(");
		sprintf(str_temp[2],"\n			  addr	    => address,						-- (in)");
		sprintf(str_temp[3],"\n			  clk	    => clk,							-- (in)");
		sprintf(str_temp[5],"\n			);");
		for(i = 0; i < n_frame; i++){
			for(j = 0; j < 4; j++){
				sprintf(str_temp[0],"\n	RAMB%03d_A%d:  entity work.FRAME%04d_A%d port map",i,j,i,j);
				sprintf(str_temp[4],"\n	 	  	  dout	    => saida_a_%03d(%02d downto %02d)	-- (out)",i,(63-(16*j)),(48-(16*j)));
				saida_vhdl << str_temp[0] << str_temp[1] << str_temp[2] << 
							  str_temp[3] << str_temp[4] << str_temp[5];
				sprintf(str_temp[0],"\n	RAMB%03d_B%d:  entity work.FRAME%04d_B%d port map",i,j,i,j);
				sprintf(str_temp[4],"\n	 	  	  dout	    => saida_b_%03d(%02d downto %02d)	-- (out)",i,(63-(16*j)),(48-(16*j)));
				saida_vhdl << str_temp[0] << str_temp[1] << str_temp[2] << 
							  str_temp[3] << str_temp[4] << str_temp[5];
			}
		}
			
		// Finaliza��o do arquivo
		saida_vhdl << "\n\nend geraframes;";
			
		saida_vhdl.close();
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Gera arquivos com m�dulos VHDL de mem�ria contendo partes do frame
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_ramb(int n_frame)
{
	char linha_hex[16];
	char aux;
	char prox_char[4];
	char prox_bit;
	char file_name[32];	
	int  i, j, k, l, m, qtd_init, num_init;
	char str_ramb[70][200];
	char linha1[64],linha2[64],linha3[64],linha4[64];
	time_t rawtime;
	struct tm * timeinfo;
	
	
	mkdir("RAMB_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

	// Abre o arquivo para escrita dos inits da RAMB1 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB1.vhd",n_frame);
	saida_ramb1.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB2 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB2.vhd",n_frame);
	saida_ramb2.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB3 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB3.vhd",n_frame);
	saida_ramb3.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB4 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB4.vhd",n_frame);
	saida_ramb4.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB5 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB5.vhd",n_frame);
	saida_ramb5.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB6 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB6.vhd",n_frame);
	saida_ramb6.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB7 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB7.vhd",n_frame);
	saida_ramb7.open(file_name, ios::out);
	// Abre o arquivo para escrita dos inits da RAMB8 do frame
	sprintf(file_name,"RAMB_OUT/FRAME%04d_RAMB8.vhd",n_frame);
	saida_ramb8.open(file_name, ios::out);
	
	// Verifica se os arquivos abriram corretamente
	if(!saida_ramb1.is_open() || !saida_ramb2.is_open() || !saida_ramb3.is_open() || !saida_ramb4.is_open() || 
	   !saida_ramb5.is_open() || !saida_ramb6.is_open() || !saida_ramb7.is_open() || !saida_ramb8.is_open())
	{
		saida_ramb1.close();
		saida_ramb2.close();
		saida_ramb3.close();
		saida_ramb4.close();
		saida_ramb5.close();
		saida_ramb6.close();
		saida_ramb7.close();
		saida_ramb8.close();
		cout << endl << "ERRO: Nao foi possivel gerar m�dulos VHDL de mem�ria contendo partes do frame!" << endl;
	}else{
		// Montagem da string para inser��o do inicio do m�dulo das RAMBs
		sprintf(str_ramb[0],"--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		sprintf(str_ramb[1],"\n--	Grupo de Apoio ao Projeto de Hardware  - GAPH");
		sprintf(str_ramb[2],"\n--	Projeto X10GiGA - FINEP/PUCRS/TERACOM");
		sprintf(str_ramb[3],"\n--");
		sprintf(str_ramb[4],"\n--	M�dulo:	Mem�ria - Gerador de Frames - Prototipa��o");
		sprintf(str_ramb[5],"\n--	Autor:	Jeferson Camargo de Oliveira\n--");		
		sprintf(str_ramb[9],"\n--");		
		sprintf(str_ramb[11],"\n--	programa gerador de frames OTN do projeto X10GiGA.");
		sprintf(str_ramb[12],"\n--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
		sprintf(str_ramb[13],"\nlibrary IEEE;");
		sprintf(str_ramb[14],"\nuse IEEE.std_logic_1164.all;");
		sprintf(str_ramb[15],"\nuse IEEE.std_logic_unsigned.all;\n");
		sprintf(str_ramb[16],"\n----Pragma translate_off");
		sprintf(str_ramb[17],"\nlibrary unisim ;");
		sprintf(str_ramb[18],"\nuse unisim.vcomponents.all ;");
		sprintf(str_ramb[19],"\n----Pragma translate_on\n");		
		sprintf(str_ramb[21],"\nport(");
		sprintf(str_ramb[22],"\n\t\taddr	: in  std_logic_vector(9 downto 0);	-- Barramento de endere�os da porta");
		sprintf(str_ramb[23],"\n\t\tclk		: in  std_logic;					-- Entrada de clock para a porta");
		sprintf(str_ramb[24],"\n\t\tdout	: out std_logic_vector(15 downto 0)	-- Sa�da de dados da porta");
		sprintf(str_ramb[25],"\n\t);");		
		sprintf(str_ramb[28],"\n\tsignal addrin	: std_logic_vector(9 downto 0);");
		sprintf(str_ramb[29],"\n\tsignal clkin	: std_logic;");
		sprintf(str_ramb[30],"\n\tsignal doutout	: std_logic_vector(15 downto 0);\n");
		sprintf(str_ramb[31],"\n\tcomponent RAMB16_S18 is");
		sprintf(str_ramb[32],"\n\tgeneric(");
		sprintf(str_ramb[33],"\n\t\tWRITE_MODE : string;");
		sprintf(str_ramb[34],"\n\t\tINIT_00,INIT_01,INIT_02,INIT_03,INIT_04,INIT_05,INIT_06,INIT_07,");
		sprintf(str_ramb[35],"\n\t\tINIT_08,INIT_09,INIT_0A,INIT_0B,INIT_0C,INIT_0D,INIT_0E,INIT_0F,");
		sprintf(str_ramb[36],"\n\t\tINIT_10,INIT_11,INIT_12,INIT_13,INIT_14,INIT_15,INIT_16,INIT_17,");
		sprintf(str_ramb[37],"\n\t\tINIT_18,INIT_19,INIT_1A,INIT_1B,INIT_1C,INIT_1D,INIT_1E,INIT_1F,");
		sprintf(str_ramb[38],"\n\t\tINIT_20,INIT_21,INIT_22,INIT_23,INIT_24,INIT_25,INIT_26,INIT_27,");
		sprintf(str_ramb[39],"\n\t\tINIT_28,INIT_29,INIT_2A,INIT_2B,INIT_2C,INIT_2D,INIT_2E,INIT_2F,");
		sprintf(str_ramb[40],"\n\t\tINIT_30,INIT_31,INIT_32,INIT_33,INIT_34,INIT_35,INIT_36,INIT_37,");
		sprintf(str_ramb[41],"\n\t\tINIT_38,INIT_39,INIT_3A,INIT_3B,INIT_3C,INIT_3D,INIT_3E,INIT_3F : bit_vector\n\t);");
		sprintf(str_ramb[42],"\n\tport(");
		sprintf(str_ramb[43],"\n\t\tDO   : out std_logic_vector(15 downto 0);	-- Port 16-bit Data Output");
		sprintf(str_ramb[44],"\n\t\tDOP  : out std_logic_vector(1  downto 0);	-- Port 2-bit Parity Output");
		sprintf(str_ramb[45],"\n\t\tADDR : in  std_logic_vector(9  downto 0); 	-- Port 10-bit Address Input");
		sprintf(str_ramb[46],"\n\t\tCLK  : in  std_logic;			 			-- Port Clock");
		sprintf(str_ramb[47],"\n\t\tDI   : in  std_logic_vector(15 downto 0); 	-- Port 16-bit Data Input");
		sprintf(str_ramb[48],"\n\t\tDIP  : in  std_logic_vector(1  downto 0); 	-- Port 2-bit parity Input");
		sprintf(str_ramb[49],"\n\t\tEN   : in  std_logic;			 			-- Port RAM Enable Input");
		sprintf(str_ramb[50],"\n\t\tSSR  : in  std_logic;			 			-- Port Synchronous Set/Reset Input");
		sprintf(str_ramb[51],"\n\t\tWE   : in  std_logic			 			-- Port Write Enable Input");
		sprintf(str_ramb[52],"\n\t);");
		sprintf(str_ramb[53],"\n\tend component;\n");
		sprintf(str_ramb[54],"\nbegin\n");
		sprintf(str_ramb[55],"\n\taddrin <= addr;");
		sprintf(str_ramb[56],"\n\tclkin  <= clk;");
		sprintf(str_ramb[57],"\n\tdout   <= doutout;\n");
		
		
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );		
		strftime(str_ramb[10],200,"\n--	M�dulo gerado em %d de %B de %Y �s %Hh%Mmin pelo",timeinfo);
		
		for(i = 0; i < 8; i++){
			sprintf(str_ramb[6],"\n-- 	FRAME:	%04d",n_frame);
			if(i < 4){
				sprintf(str_ramb[7],"\n-- 	RAMB:	%02d",i);
				sprintf(str_ramb[8],"\n-- 	CONJ:	A");
				sprintf(str_ramb[20],"\nentity FRAME%04d_A%d is",n_frame,i);	
				sprintf(str_ramb[26],"\nend FRAME%04d_A%d;\n",n_frame,i);
				sprintf(str_ramb[27],"\narchitecture FRAME%04d_A%d of FRAME%04d_A%d is\n",n_frame,i,n_frame,i);
			}else{
				sprintf(str_ramb[7],"\n-- 	RAMB:	%02d",i-4);
				sprintf(str_ramb[8],"\n-- 	CONJ:	B");
				sprintf(str_ramb[20],"\nentity FRAME%04d_B%d is",n_frame,i-4);
				sprintf(str_ramb[26],"\nend FRAME%04d_B%d;\n",n_frame,i-4);
				sprintf(str_ramb[27],"\narchitecture FRAME%04d_B%d of FRAME%04d_B%d is\n",n_frame,i-4,n_frame,i-4);
			}
			
			// Insere inicio do m�dulo
			switch(i){
				case 0: for(j = 0; j < 58; j++) saida_ramb1 << str_ramb[j]; break;
				case 1: for(j = 0; j < 58; j++) saida_ramb2 << str_ramb[j]; break;
				case 2: for(j = 0; j < 58; j++) saida_ramb3 << str_ramb[j]; break;
				case 3: for(j = 0; j < 58; j++) saida_ramb4 << str_ramb[j]; break;
				case 4: for(j = 0; j < 58; j++) saida_ramb5 << str_ramb[j]; break;
				case 5: for(j = 0; j < 58; j++) saida_ramb6 << str_ramb[j]; break;
				case 6: for(j = 0; j < 58; j++) saida_ramb7 << str_ramb[j]; break;
				case 7: for(j = 0; j < 58; j++) saida_ramb8 << str_ramb[j]; break;
				default: break;        
			}
		} 

		// Montagem da string para inser��o do inicio do port map das RAMBs
		sprintf(str_ramb[2],"\n\tgeneric map (\n");
		sprintf(str_ramb[3],"\n\t\t-- The following generics are only necessary if you wish to change the default behavior.");
		sprintf(str_ramb[4],"\n\t\tWRITE_MODE => %cNO_CHANGE%c, 	-- WRITE_FIRST, READ_FIRST or NO_CHANGE",'"','"');
		sprintf(str_ramb[5],"\n");
		sprintf(str_ramb[6],"\n\t\t-- The following generic INIT_xx declarations are only necessary");
		sprintf(str_ramb[7],"\n\t\t-- if you wish to change the initial contents of the RAM to anything");
		sprintf(str_ramb[8],"\n\t\t-- other than all zero's.\n");
		
		for(i = 0; i < 8; i++){
			sprintf(str_ramb[0],"\n\t-- FRAME%04d_RAMB%02d instantiation",n_frame,i);
			sprintf(str_ramb[1],"\n\tFRAME%04d_RAMB%02d : RAMB16_S18",n_frame,i);
			// Insere inicio dos port maps
			switch(i){
				case 0: for(j = 0; j < 9; j++) saida_ramb1 << str_ramb[j]; break;
				case 1: for(j = 0; j < 9; j++) saida_ramb2 << str_ramb[j]; break;
				case 2: for(j = 0; j < 9; j++) saida_ramb3 << str_ramb[j]; break;
				case 3: for(j = 0; j < 9; j++) saida_ramb4 << str_ramb[j]; break;
				case 4: for(j = 0; j < 9; j++) saida_ramb5 << str_ramb[j]; break;
				case 5: for(j = 0; j < 9; j++) saida_ramb6 << str_ramb[j]; break;
				case 6: for(j = 0; j < 9; j++) saida_ramb7 << str_ramb[j]; break;
				case 7: for(j = 0; j < 9; j++) saida_ramb8 << str_ramb[j]; break;
				default: break;
			}
		} 
		
		//Inicializa��es
		qtd_init  = 16;
		num_init  = 0;
		tam_linha = 0;
		
		for(i = 0; i < 1020; i++){
			for(j = 0; j < 16; j++){
				aux = frame[i][j];
				for(k = 0; k < 8; k++){
					if(aux & 0x80){
						prox_bit = '1';
					}else{
						prox_bit = '0';
					}
					aux <<= 1;
					
					// Embaralha tudo, menos o FAS
					if(SCRAMBLING && (i > 0 || j > 5)) linha[tam_linha] = scrambler(prox_bit);
					else linha[tam_linha] = prox_bit;
					tam_linha++;
					
					if(tam_linha == TAMLINHA){
						tam_linha = 0;
						
						// Cria vetor da linha em hexadecimal
						for(l = 0; l < 16; l++){
							for(m = 0; m < 4; m++) prox_char[m] = linha[l*4+m];
							linha_hex[l] = convert_bin2ascii(prox_char);
						}
						
						// Monta linhas a serem inseridas nos arquivos
						for(l=4; l>0; l--) linha1[(4*qtd_init)-l]=linha_hex[4-l];
						for(l=4; l>0; l--) linha2[(4*qtd_init)-l]=linha_hex[8-l];
						for(l=4; l>0; l--) linha3[(4*qtd_init)-l]=linha_hex[12-l];
						for(l=4; l>0; l--) linha4[(4*qtd_init)-l]=linha_hex[16-l];
						
						qtd_init--;
						
						// Condi��es para inserir o resto da �ltima linha (3F) do conjunto B de RAMBs
						if(i == 1019 && j == 15 && k == 7){
							for(l = 0; l < 32; l++){
								linha1[l] = '1';
								linha2[l] = '1';
								linha3[l] = '1';
								linha4[l] = '1';
							}
							qtd_init = 0;
						}
						
						// Quando completas as 4 linhas para inserir nos arquivos � escolhido qual conjunto de RAMBs � utilizado
						if(qtd_init == 0){
							qtd_init = 16;
							if(num_init < 64){
								saida_ramb1 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << num_init << " => x" << '"';
								saida_ramb2 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << num_init << " => x" << '"';
								saida_ramb3 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << num_init << " => x" << '"';
								saida_ramb4 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << num_init << " => x" << '"';
								
								for(l = 0; l < 64; l++) saida_ramb1 << linha1[l];
								if(!(num_init == 63)) saida_ramb1 << '"' << ",\r\n"; else saida_ramb1 << '"';
								for(l = 0; l < 64; l++) saida_ramb2 << linha2[l];
								if(!(num_init == 63)) saida_ramb2 << '"' << ",\r\n"; else saida_ramb2 << '"';
								for(l = 0; l < 64; l++) saida_ramb3 << linha3[l];
								if(!(num_init == 63)) saida_ramb3 << '"' << ",\r\n"; else saida_ramb3 << '"';
								for(l = 0; l < 64; l++) saida_ramb4 << linha4[l];
								if(!(num_init == 63)) saida_ramb4 << '"' << ",\r\n"; else saida_ramb4 << '"';
								
							}else{
								saida_ramb5 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << (num_init - 64) << " => x" << '"';
								saida_ramb6 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << (num_init - 64) << " => x" << '"';
								saida_ramb7 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << (num_init - 64) << " => x" << '"';
								saida_ramb8 << "\t\tINIT_" << setw(2) << setfill('0') << uppercase << hex << (num_init - 64) << " => x" << '"';
								
								for(l = 0; l < 64; l++) saida_ramb5 << linha1[l];
								if(!(num_init == 127)) saida_ramb5 << '"' << ",\r\n"; else saida_ramb5 << '"';
								for(l = 0; l < 64; l++) saida_ramb6 << linha2[l];
								if(!(num_init == 127)) saida_ramb6 << '"' << ",\r\n"; else saida_ramb6 << '"';
								for(l = 0; l < 64; l++) saida_ramb7 << linha3[l];
								if(!(num_init == 127)) saida_ramb7 << '"' << ",\r\n"; else saida_ramb7 << '"';
								for(l = 0; l < 64; l++) saida_ramb8 << linha4[l];
								if(!(num_init == 127)) saida_ramb8 << '"' << ",\r\n"; else saida_ramb8 << '"';
								
							}
							num_init++;
						}
					}
				}
			}
		}
		
		// Montagem da string para inser��o do final do port map das RAMBs
		sprintf(str_ramb[0],"\n\t)port map (");		
		sprintf(str_ramb[2],"\n\t\tDOP  => open,				-- Port 2-bit Parity Output");
		sprintf(str_ramb[3],"\n\t\tADDR => addrin,				-- Port 10-bit Address Input");
		sprintf(str_ramb[4],"\n\t\tCLK  => clkin, 				-- Port Clock");
		sprintf(str_ramb[5],"\n\t\tDI   => (others => '0'),	-- Port 16-bit Data Input");
		sprintf(str_ramb[6],"\n\t\tDIP  => (others => '0'),	-- Port 2-bit parity Input");
		sprintf(str_ramb[7],"\n\t\tEN   => '1',				-- Port RAM Enable Input");
		sprintf(str_ramb[8],"\n\t\tSSR  => '0',				-- Port Synchronous Set/Reset Input");
		sprintf(str_ramb[9],"\n\t\tWE   => '0'					-- Port Write Enable Input");
		sprintf(str_ramb[10],"\n\t);");
		
		for(i = 0; i < 8; i++){
			sprintf(str_ramb[11],"\n\t-- End of FRAME%04d_RAMB%02d instantiation",n_frame, i);
			if(i < 4){
				sprintf(str_ramb[12],"\n\nend FRAME%04d_A%d;",n_frame, i);
			}else{
				sprintf(str_ramb[12],"\n\nend FRAME%04d_B%d;",n_frame, i-4);
			}
			
			// Insere final dos port maps
			switch(i){
				case 0: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb1 << str_ramb[j];
						break;
				case 1: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb2 << str_ramb[j];
						break;
				case 2: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb3 << str_ramb[j];
						break;
				case 3: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb4 << str_ramb[j];
						break;
				case 4: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb5 << str_ramb[j];
						break;
				case 5: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb6 << str_ramb[j];
						break;
				case 6: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb7 << str_ramb[j];
						break;
				case 7: sprintf(str_ramb[1],"\n\t\tDO   => doutout,			-- Port 16-bit Data Output",n_frame);
						for(j = 0; j < 13; j++) saida_ramb8 << str_ramb[j];
						break;
				default: break;
			}
		}		
		
		// Fecha arquivos
		saida_ramb1.close();
		saida_ramb2.close();
		saida_ramb3.close();
		saida_ramb4.close();
		saida_ramb5.close();
		saida_ramb6.close();
		saida_ramb7.close();
		saida_ramb8.close();
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Gera arquivo com script para simula��o do gerador de frames
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_script(int n_frame)
{
	char file_name[32];	
	int i, j;
	char str_temp[200];
	time_t rawtime;
	struct tm * timeinfo;
	
	mkdir("RAMB_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	
	// Abre o arquivo para escrita do template vhdl
	sprintf(file_name,"RAMB_OUT/x10_geraframes.do");
	saida_script.open(file_name, ios::out);
	
	if(!saida_script.is_open()){
		saida_script.close();
		cout << endl << "ERRO: Nao foi possivel gerar o script para simula��o do gerador de frames!" << endl;
	}else{
		saida_script << "##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_script << "\n##	Grupo de Apoio ao Projeto de Hardware  - GAPH";
		saida_script << "\n##	Projeto X10GiGA - FINEP/PUCRS/TERACOM";
		saida_script << "\n## ";
		saida_script << "\n##	Script:	Simula��o - Gerador de Frames";
		saida_script << "\n##	Autor:	Jeferson Camargo de Oliveira";
		saida_script << "\n##";
		
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );		
		strftime(str_temp,200,"\n##	Script gerado em %d de %B de %Y �s %Hh%Mmin pelo",timeinfo);
		saida_script << str_temp;
		
		saida_script << "\n##	programa gerador de frames OTN do projeto X10GiGA.";
		saida_script << "\n##+++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_script << "\nquit -sim";
		saida_script << "\nvmap unisim 	   C:/Xilinx92i/vhdl/mti_se/unisim";
		saida_script << "\nvmap simprim 	   C:/Xilinx92i/vhdl/mti_se/simprim";
		saida_script << "\nvlib work";
		
		for(i = 0; i < n_frame; i++){
			for(j = 0; j < 8; j++){
				sprintf(str_temp,"\nvcom -work work    FRAME%04d_RAMB%d.vhd",i,j+1);
				saida_script << str_temp;
			}
		}
		
		saida_script << "\nvcom -work work    x10_geraframes.vhd";
		saida_script << "\nvcom -work work    x10_geraframes_tb.vhd";
		saida_script << "\nvsim -t 1ps -lib work x10_testbench";
		saida_script << "\nradix hexadecimal";
		saida_script << "\nadd wave 	-divider Gerador";
		saida_script << "\nadd wave	-label rst			sim:/x10_testbench/uut/rst";
		saida_script << "\nadd wave	-label clk			sim:/x10_testbench/uut/clk";
		saida_script << "\nadd wave	-label saida		sim:/x10_testbench/uut/saida";
		saida_script << "\nadd wave	-label address		sim:/x10_testbench/uut/address";
		saida_script << "\nadd wave	-label counter		sim:/x10_testbench/uut/counter";
		saida_script << "\nadd wave	-label conjunto		sim:/x10_testbench/uut/conjunto";
		saida_script << "\nadd wave	-label counter_ram	sim:/x10_testbench/uut/counter_ram";
		saida_script << "\nadd wave	-label start		sim:/x10_testbench/uut/start";	
		saida_script << "\nrun " << 12*n_frame << " us";
		
		saida_script.close();
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Gera arquivo com testbench em VHDL para simula��o do gerador de frames
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void gera_testbench()
{
	char file_name[32];	
	char str_temp[200];
	time_t rawtime;
	struct tm * timeinfo;
	
	mkdir("RAMB_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
	
	// Abre o arquivo para escrita do template vhdl
	sprintf(file_name,"RAMB_OUT/x10_geraframes_tb.vhd");
	saida_tb.open(file_name, ios::out);
	
	if(!saida_tb.is_open()){
		saida_tb.close();
		cout << endl << "ERRO: Nao foi possivel gerar o template vhdl do gerador de frames!" << endl;
	}else{
		saida_tb << "--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_tb << "\n--	Grupo de Apoio ao Projeto de Hardware  - GAPH";
		saida_tb << "\n--	Projeto X10GiGA - FINEP/PUCRS/TERACOM";
		saida_tb << "\n-- ";
		saida_tb << "\n--	M�dulo:	Testbench - Gerador de Frames";
		saida_tb << "\n--	Autor:	Jeferson Camargo de Oliveira";
		saida_tb << "\n--";
		
		time ( &rawtime );
		timeinfo = localtime ( &rawtime );		
		strftime(str_temp,200,"\n--	Testbench gerado em %d de %B de %Y �s %Hh%Mmin pelo",timeinfo);
		saida_tb << str_temp;
		
		saida_tb << "\n--	programa gerador de frames OTN do projeto X10GiGA.";
		saida_tb << "\n--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
		saida_tb << "\nlibrary IEEE;";
		saida_tb << "\nuse IEEE.STD_LOGIC_1164.all;";
		saida_tb << "\nuse IEEE.STD_LOGIC_unsigned.all;";
		saida_tb << "\n";
		saida_tb << "\nentity x10_testbench is";
		saida_tb << "\nend x10_testbench;";
		saida_tb << "\n";
		saida_tb << "\narchitecture x10_testbench of x10_testbench is";
		saida_tb << "\n";
		saida_tb << "\nsignal clk		: std_logic := '1'; ";
		saida_tb << "\nsignal rst		: std_logic := '1';";
		saida_tb << "\nsignal saida	: std_logic_vector(63 downto 0);";
		saida_tb << "\n";
		saida_tb << "\nbegin";
		saida_tb << "\n";
		saida_tb << "\n	process";
		saida_tb << "\n	  variable delay : time := 200 ns;";
		saida_tb << "\n	begin";
		saida_tb << "\n	  clk <= '0';";
		saida_tb << "\n	  wait for delay;";
		saida_tb << "\n	  wait for 2.5 ns;";
		saida_tb << "\n	  clk <= '1';";
		saida_tb << "\n	  delay := 0 ns;";
		saida_tb << "\n	  wait for 2.5 ns;";
		saida_tb << "\n	end process;";
		saida_tb << "\n";
		saida_tb << "\n	rst <= '0', '1' after 10 ns, '0' after 300 ns;";
		saida_tb << "\n	";
		saida_tb << "\n	uut: entity work.geraframes port map ";
		saida_tb << "\n				(";
		saida_tb << "\n					clk   => clk,";
		saida_tb << "\n					rst   => rst,";
		saida_tb << "\n					saida => saida";
		saida_tb << "\n				);";
		saida_tb << "\n ";
		saida_tb << "\nend x10_testbench;";
		
		saida_tb.close();
	}
}
