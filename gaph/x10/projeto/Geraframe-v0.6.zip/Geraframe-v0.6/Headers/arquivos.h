// Fun��es Utilizadas
void abre_arquivos(int r);
void fecha_arquivos(void);
int insere_desalinhamento(int bits_desalinhamento);
int insere_frame(void);
void print_line2file();
int insere_resto(void);
void insere_ramb(int n_frame);
/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Abre os arquivos de sa�da
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void abre_arquivos(int r){
	char file_name[32];
	
	mkdir("FILE_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);

	// Abre o arquivo para escrita em bin�rio
	if(BASE_OUT!=3){
		sprintf(file_name,"FILE_OUT/%s_bin%04d.out",FILE_OUT,r);
		saida_bin.open(file_name, ios::out);
	}

	// Abre o arquivo para escrita em hexadecimal
	if(BASE_OUT!=2){
		sprintf(file_name,"FILE_OUT/%s_hex%04d.out",FILE_OUT,r);
		saida_hex.open(file_name, ios::out);
	}

	// Verifica se os arquivos bin/hex abriram corretamente
	if(!saida_bin.is_open() || !saida_hex.is_open()){
		saida_bin.close();
		saida_hex.close();
		cout << endl << "ERRO: Nao foi possivel gerar arquivo de saida!" << endl;
	}

	// Abre o arquivo de assinatura
	if(ASSINATURA == 1){
		mkdir("ASSINATURA_OUT", S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
		sprintf(file_name,"ASSINATURA_OUT/assinatura_%04d.txt",r);
		saida_assinatura.open(file_name, ios::out);
		if(!saida_assinatura.is_open()){
			saida_assinatura.close();
			cout << endl << "ERRO: Nao foi possivel gerar arquivo de assinatura!" << endl;
		}
	}
	
	// Abre o arquivo com a sa�da de forma estrutural
	sprintf(file_name,"%s.graph",FILE_OUT);
	saida_quadro.open(file_name, ios::out);
	
	if(!saida_quadro.is_open()){
		saida_quadro.close();		
		cout << endl << "ERRO: Nao foi possivel gerar arquivo de saida!" << endl;
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Fecha os arquivos de sa�da
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void fecha_arquivos(void){
	if(BASE_OUT!=3) saida_bin.close();
	if(BASE_OUT!=2) saida_hex.close();
	if(ASSINATURA == 1) saida_assinatura.close();
	if(saida_quadro.is_open()) saida_quadro.close();
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Insere desalinhamento
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int insere_desalinhamento(int bits_desalinhamento)
{
	int i;

	tam_linha = 0;
	
	for(i=0; i<bits_desalinhamento; i++){
		linha[tam_linha] = '0';
		tam_linha++;
		if(tam_linha == TAMLINHA){
			tam_linha = 0;
			print_line2file();
		}
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Insere frame no arquivo
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int insere_frame(void)
{
	int i, j, k;
	char aux, prox_bit,BUGED[50];
	
	if(tam_linha == TAMLINHA) cout << endl << "Waning!! - DEBUG_MSG";
	
	for(i = 0; i < 1020; i++){
		for(j = 0; j < 16; j++){
			aux = frame[i][j];
			for(k = 0; k < 8; k++){
				if(aux & 0x80){
					prox_bit = '1';
				}else{
					prox_bit = '0';
				}
				aux <<= 1;
				// Embaralha tudo, menos o FAS
				if(SCRAMBLING && (i > 0 || j > 5)){
					linha[tam_linha] = scrambler(prox_bit);
				}else{
					linha[tam_linha] = prox_bit;
				}
				tam_linha ++;
				if(tam_linha == TAMLINHA){
					tam_linha = 0;
					print_line2file();
					//Assinatura
					if(ASSINATURA) assinatura(linha);
				}
			}
		}
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Insere resto do sinal (o que nao completou de uma word de 64 bits)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
int insere_resto(void)
{
	int i;

	if(tam_linha){
		for(i = tam_linha; i < TAMLINHA; i++) linha[i] = '0';
		print_line2file();
	}
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime linha no arquivo de saida (bin ou hex)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void print_line2file()
{
	int i, j;
	char prox_char[4];

	if(BASE_OUT!=3){
		for(i=0; i < TAMLINHA; i++) saida_bin << linha[i];
		saida_bin << "\r\n";
	}

	if(BASE_OUT!=2){
		for(i=0; i < 16; i++){
			for(j=0; j < 4; j++) prox_char[j] = linha[i*4+j];
			saida_hex << convert_bin2ascii(prox_char);
		}
		saida_hex << "\r\n";
	}
}


/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 Imprime os Quadros
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void print_frame_graph(int r)
{
	int i, j, k;
	char *word;
	
	saida_quadro << "FRAME" << setw(3) << setfill('0') << r << "\r\n";
	saida_quadro << "| 1| 2|...      ... 7| 8|...         ...14|15|16|17...";
	for(i=0;i<11411;i++) saida_quadro << ' ';
	saida_quadro << "...3824|3825...";
	for(i=0;i<753;i++) saida_quadro << ' ';
	saida_quadro << "...4080|";
	
	saida_quadro << "\r\n|";
	for(i=0;i<12239;i++) saida_quadro << '-';
	saida_quadro << "|\r\n|";
	
	for(k=0;k<4;k++){
		for(i=0;i<255;i++){
			for(j=0;j<16;j++){
				word = conv_byte2char(frame[i+k*255][j]);
				saida_quadro << word[1] << word[0] << '|';
			}
		}	
		saida_quadro << "\r\n|";
		for(i=0;i<12239;i++) saida_quadro << '-';
		saida_quadro << "|\r\n|";
	}	
	saida_quadro << "\r\n";
}
