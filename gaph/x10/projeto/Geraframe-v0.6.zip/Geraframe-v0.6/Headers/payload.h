/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Arquivo : payload.h	
	Descri��o: cuiada da gera��o do payload	
	Vers�o Utilizada: 0.4
	�ltima Modfica��o: Ferlini 25/09/08 (inser��o da parte do JC)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/

// Fun��es Utilizadas
void insere_null(void);
long unsigned int rand31_next(void);
char rand31_next_byte(void);
void insere_prbs(void);

// PRBS
bitset<31> rand31_bin;
string rand31_str;
int point = 0;

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Insere payload com sinal de teste nulo (NULL Test Signal)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void insere_null(void)
{
	int i, j, j_init;
	
	if(NJO>=2) frame[765][15] = 0x00;	
	if(PJO>=2) j_init = 1;
	else j_init = 0;
	frame[766][0] = 0x00;
	
	// Insere payload do primeiro subframe
	cout << endl << "\t000%\tConclu�do";
	for(i = 1; i < 239; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = 0x00;
		}
	}
	
	// Insere payload do segundo subframe
	cout << endl << "\t025%\tConclu�do";
	for(i = 256; i < 494; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = 0x00;
		}
	}
	
	// Insere payload do terceiro subframe
	cout << endl << "\t050%\tConclu�do";
	for(i = 511; i < 749; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = 0x00;
		}
	}
	
	// Insere payload do quarto subframe
	cout << endl << "\t075%\tConclu�do";
	for(i = 766; i < 1004; i++){
		for(j = j_init; j < 16; j++){
			frame[i][j] = 0x00;
		}
	}
	
	cout << endl << "\t100%\tConclu�do";
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Park-Miller "minimal standard" 31 bit
	pseudo-random number generator, implemented
	with David G. Carta's optimisation: with
	32 bit math and without division.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */
long unsigned int rand31_next(void)
{
	long unsigned int hi, lo;

	lo = 16807 * (seed & 0xFFFF);
	hi = 16807 * (seed >> 16);

	lo += (hi & 0x7FFF) << 16;
	lo += hi >> 15;

	if (lo > 0x7FFFFFFF) lo  -= 0x7FFFFFFF;

	return (seed = (long)lo);
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Monta byte pseudo randomico para inser��o no payload
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */
char rand31_next_byte(void)
{
	int i;
	char lo[4];
	char out_hi, out_lo, out;
	char hi[4];
	
	
	for(i = 0; i < 8; i++){
		if(i < 4){
			hi[i] = rand31_str[point];
		}else{
			lo[i-4] = rand31_str[point];
		}
		if(point == 30){
			rand31_bin = (long) rand31_next();
			rand31_str = rand31_bin.to_string<char,char_traits<char>,allocator<char> >();
			point 	   = -1;
		}
		point++;
	}
	
	out_hi = convert_bin2hex(hi);
	out_lo = convert_bin2hex(lo);
	out_hi = out_hi << 4;
	out = out_hi | out_lo;

	return out;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Insere payload com sinal de teste pseudo-aleat�rio (PRBS Test Signal)
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
void insere_prbs(void)
{
	int i, j, j_init;
	char aux;
	int aux_int,k;

	rand31_bin = (long) rand31_next();
	rand31_str = rand31_bin.to_string<char,char_traits<char>,allocator<char> >();
	
	// Insere payload do primeiro subframe
	cout << endl << "\t000%\tConclu�do";
	for(i = 1; i < 239; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = rand31_next_byte();
		}
	}
	
	// Insere payload do segundo subframe
	cout << endl << "\t025%\tConclu�do";
	for(i = 256; i < 494; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = rand31_next_byte();
		}
	}
	
	// Insere payload do terceiro subframe
	cout << endl << "\t050%\tConclu�do";
	for(i = 511; i < 749; i++){
		for(j = 0; j < 16; j++){
			frame[i][j] = rand31_next_byte();
		}
	}
	
	//Insere as Justificativas
	if(NJO>=2) frame[765][15] = rand31_next_byte();
	if(PJO>=2) j_init = 1;
	else j_init = 0;
	frame[766][0] = 0x00;
	
	// Insere payload do quarto subframe
	cout << endl << "\t075%\tConclu�do";
	for(i = 766; i < 1004; i++){
		for(j = j_init; j < 16; j++){
			frame[i][j] = rand31_next_byte();
		}
	}
	
	cout << endl << "\t100%\tConclu�do";
}
