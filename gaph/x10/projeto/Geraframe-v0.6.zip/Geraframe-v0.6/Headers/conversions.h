/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Converte bin�rio para hexadecimal
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
unsigned char convert_bin2hex(char bin[4])
{
	switch(atoi(bin)){
		case    0: return 0x00;
		case    1: return 0x01;
		case   10: return 0x02;
		case   11: return 0x03;
		case  100: return 0x04;
		case  101: return 0x05;
		case  110: return 0x06;
		case  111: return 0x07;
		case 1000: return 0x08;
		case 1001: return 0x09;
		case 1010: return 0x0A;
		case 1011: return 0x0B;
		case 1100: return 0x0C;
		case 1101: return 0x0D;
		case 1110: return 0x0E;
		case 1111: return 0x0F;
		default: break;
	}
	return 'X';
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Converte bin�rio para ascii
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char convert_bin2ascii(char bin[4])
{
	switch(atoi(bin)){
		case    0: return '0';
		case    1: return '1';
		case   10: return '2';
		case   11: return '3';
		case  100: return '4';
		case  101: return '5';
		case  110: return '6';
		case  111: return '7';
		case 1000: return '8';
		case 1001: return '9';
		case 1010: return 'A';
		case 1011: return 'B';
		case 1100: return 'C';
		case 1101: return 'D';
		case 1110: return 'E';
		case 1111: return 'F';
		default: break;
	}
	return 'X';
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Converte integer para hexa
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char convert_int2hex(int dec)
{
	char hex[3], saida;
	
	sprintf(hex, "%02x", dec);
	
	switch(hex[0]){
		case '0' : saida = 0x00; break;
		case '1' : saida = 0x10; break;
		case '2' : saida = 0x20; break;
		case '3' : saida = 0x30; break;
		case '4' : saida = 0x40; break;
		case '5' : saida = 0x50; break;
		case '6' : saida = 0x60; break;
		case '7' : saida = 0x70; break;
		case '8' : saida = 0x80; break;
		case '9' : saida = 0x90; break;
		case 'a' : saida = 0xA0; break;
		case 'b' : saida = 0xB0; break;
		case 'c' : saida = 0xC0; break;
		case 'd' : saida = 0xD0; break;
		case 'e' : saida = 0xE0; break;
		case 'f' : saida = 0xF0; break;
		default  : saida = 'X';  break;
	}
	switch(hex[1]){
		case '0' : saida |= 0x00; break;
		case '1' : saida |= 0x01; break;
		case '2' : saida |= 0x02; break;
		case '3' : saida |= 0x03; break;
		case '4' : saida |= 0x04; break;
		case '5' : saida |= 0x05; break;
		case '6' : saida |= 0x06; break;
		case '7' : saida |= 0x07; break;
		case '8' : saida |= 0x08; break;
		case '9' : saida |= 0x09; break;
		case 'a' : saida |= 0x0A; break;
		case 'b' : saida |= 0x0B; break;
		case 'c' : saida |= 0x0C; break;
		case 'd' : saida |= 0x0D; break;
		case 'e' : saida |= 0x0E; break;
		case 'f' : saida |= 0x0F; break;
		default  : saida = 'X';  break;
	} 

	return saida;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Converte ascii para hexa
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char convert_ascii2hex(char ascii[2])
{
	char saida;
	
	switch(ascii[0]){
		case '0' : saida = 0x00; break;
		case '1' : saida = 0x10; break;
		case '2' : saida = 0x20; break;
		case '3' : saida = 0x30; break;
		case '4' : saida = 0x40; break;
		case '5' : saida = 0x50; break;
		case '6' : saida = 0x60; break;
		case '7' : saida = 0x70; break;
		case '8' : saida = 0x80; break;
		case '9' : saida = 0x90; break;
		case 'A' : saida = 0xA0; break;
		case 'B' : saida = 0xB0; break;
		case 'C' : saida = 0xC0; break;
		case 'D' : saida = 0xD0; break;
		case 'E' : saida = 0xE0; break;
		case 'F' : saida = 0xF0; break;
		default  : saida = 'X';  break;
	}
	switch(ascii[1]){
		case '0' : saida |= 0x00; break;
		case '1' : saida |= 0x01; break;
		case '2' : saida |= 0x02; break;
		case '3' : saida |= 0x03; break;
		case '4' : saida |= 0x04; break;
		case '5' : saida |= 0x05; break;
		case '6' : saida |= 0x06; break;
		case '7' : saida |= 0x07; break;
		case '8' : saida |= 0x08; break;
		case '9' : saida |= 0x09; break;
		case 'A' : saida |= 0x0A; break;
		case 'B' : saida |= 0x0B; break;
		case 'C' : saida |= 0x0C; break;
		case 'D' : saida |= 0x0D; break;
		case 'E' : saida |= 0x0E; break;
		case 'F' : saida |= 0x0F; break;
		default  : saida = 'X';  break;
	}
	return saida;
}

/* 
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	Converte hexa para ascii
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
*/
char * conv_byte2char(char c){
	int i, t;
	unsigned char tmp;
	char *resp = new char[2];
	
	tmp = c;
	
	for(i=0;i<2;i++){
		t = (tmp & 0x0F);
		switch(t){
		case 0 : resp[i] = '0'; break;
		case 1 : resp[i] = '1'; break;
		case 2 : resp[i] = '2'; break;
		case 3 : resp[i] = '3'; break;
		case 4 : resp[i] = '4'; break;
		case 5 : resp[i] = '5'; break;
		case 6 : resp[i] = '6'; break;
		case 7 : resp[i] = '7'; break;
		case 8 : resp[i] = '8'; break;
		case 9 : resp[i] = '9'; break;
		case 10: resp[i] = 'A'; break;
		case 11: resp[i] = 'B'; break;
		case 12: resp[i] = 'C'; break;
		case 13: resp[i] = 'D'; break;
		case 14: resp[i] = 'E'; break;
		case 15: resp[i] = 'F'; break;
		default: resp[i] = 'X'; break;
		}
		tmp >>= 4;
	}
	return resp;
}
