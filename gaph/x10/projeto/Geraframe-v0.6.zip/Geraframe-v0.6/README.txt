
	README.txt - Este arquivo contem algumas explicacoes para organizacao do geraframe

	GERAFRAME

	Para limpar os diretorios e apagar o executavel para uma nova compilacao:
	Nota: Este comando tambem apaga os arquivos de saida anteriores do geraframe.
	
		$ make clean

	Para compilar, dentro do diretorio do geraframe:
	
		$ make
		
	Para rodar, dentro do mesmo diretorio:
	
		$ ./geraframe <args>

        Args: -h  : arquivo de ajuda
              -cf : seta arquivo de configuracao
              -qf : seta a quantidade de frames
	
	Organizacao do geraframe:
	
		geraframe/			Diretorio raiz do geraframe
			configs/		Diretorio com arquivos de configuracao
			headers/		Diretorio com as bibliotecas de funcoes
			sources/		Diretorio com os codigos fonte
