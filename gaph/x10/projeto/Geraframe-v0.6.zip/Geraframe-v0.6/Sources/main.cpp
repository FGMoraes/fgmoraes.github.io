
/********************************************************************************************
**	Arquivo : geraframe.h	
**	Descri��o: interface do programa, respons�vel por chamar as fun��es	
**	Vers�o Utilizada: 0.4
**	�ltima Modfica��o: Ferlini 25/09/08 (inser��o da parte do JC)
*********************************************************************************************/

#include "../Headers/biblioteca.h"
#include "../Headers/global.h"
#include "../Headers/conversions.h"
#include "../Headers/config.h"
#include "../Headers/interfaces.h"
#include "../Headers/scrambler.h"
#include "../Headers/assinatura.h"
#include "../Headers/arquivos.h"
#include "../Headers/overheads.h"
#include "../Headers/payload.h"
#include "../Headers/fec.h"
#include "../Headers/erros.h"
#include "../Headers/gerador.h"
#include "../Headers/geradorFrameHandler.h"

// Fun��es Utilizadas
void build_frame(int i);

/********************************************************************************************
** Gerador de Frames OTN para Simulacao do Projeto X10GiGA
*********************************************************************************************/

int main(int argc, char *argv[])
{
	int i, repeticoes, cont = 0;
	bool entrada, continua;
	int j,k; //debug
	char prox_bit, aux;

	entrada = true;

	// Adicionado por Leandro Heck
	// Recebimento de argumentos pela chamada do programa pra facilitar a gera��o de testes
	// Argumento 0: Necessariamente � o nome do programa! 

	printf("\n");
	
	if (argc != 0 )
	{
		// Mostra os argumentos que temos, comentar depois...
		//for (cont = 0; cont < argc; cont++) { printf("ARG %d: %s\n", cont, argv[cont]); }
		printf("\n");
		for (cont = 0; cont < argc; cont++) 
		{ 
			//HELP
			if (strcmp(argv[cont],"-h") == 0) 
			{
					system("clear");
					printf("\n\n\tGeraFrames\n\n\t\tPrograma gerador de frames do Projeto X10GiGa\n");
					printf("\n\tUso: %s <args>\n", argv[0]);
					printf("\n\tArgs (opcional):\n");
					printf("\n\t\t -h              : imprime este help");
					printf("\n\t\t -cf <filename>  : seleciona arquivo de configuracao");
					printf("\n\t\t -qf <qdtframes> : seta a quantidade de frames a serem gerados\n\n");
					return 0;
			}		
			// CONFIG FILE
			if (strcmp(argv[cont],"-cf") == 0) 
			{
				strcpy(arquivo_config,argv[cont+1]);
				flagcf = 1;
			}
			if (strcmp(argv[cont],"-qf") == 0) 
			{
				qt_frames = atoi(argv[cont+1]);
				flagqf = 1;
			}
		}
	}

	// Final da parte adicionada pro Leandro Heck
	
	//cout << "\33[2J";
	cout << endl <<" ==========================================================" << endl
				 <<" ====== GRUPO DE APOIO AO PROJETO DE HARDWARE (GAPH) ======" << endl
				 <<" ==========================================================" << endl
				 <<" ==================== PROJETO X10GiGA =====================" << endl
	 			 <<" ==========================================================" << endl
				 <<" ================ PUCRS / TERACOM / FINEP =================" << endl
				 <<" ==========================================================" << endl
				 <<" ==========================================================" << endl
				 <<" ================= GERADOR DE FRAMES OTN ==================" << endl
				 <<" ==========================================================" << endl
	 			 <<" ============================================ Vers�o 2.1 ==" << endl;
	do{
		// Imprime interface principal
		if(entrada) interface_principal();

		if(ut_config != 2){
			// Carrega configura��es
			carrega_config();
			
			// Abre arquivos com nomes diferentes de acordo com as repeticoes
			abre_arquivos(repeticoes);

			//Inicializacao de variaveis
			tam_linha = 0;

			// Insere desalinhamento
			insere_desalinhamento(ALIGNMENT);
			
			// Insere frames
			for(i = 0; i < qt_frames; i++){
				// Monta Frame
				build_frame(i);
				// Reseta scrambler
				if(SCRAMBLING) reset_scram();
				//Imprime a estrutura do quadro completo
				if(PRINT_AFTER==5) print_frame_graph(i);
				//Insere frame
				insere_frame();
				//Cria arquivos com m�dulos VHDL de mem�ria contendo partes do frame
				if(RAMB_OUT){
					cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Gerando m�dulos VHDL de mem�ria contendo partes do frame";
					if(SCRAMBLING) reset_scram();
					gera_ramb(i);
					cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: M�dulos VHDL de mem�ria contendo partes do frame gerados";
				}
			}

			// Cria arquivos VHDL (top e testbench) e script de simula��o do gerador de frames
			if(RAMB_OUT){
				cout << endl << "\nFINALIZANDO :: Gerando m�dulo VHDL gerador de frames para prototipa��o";
				gera_template_vhdl(qt_frames);
				gera_frameHandler_vhdl(qt_frames);
				cout << endl << "FINALIZANDO :: M�dulo VHDL gerador de frames para prototipa��o gerado";
				cout << endl << "FINALIZANDO :: Gerando testbench para simula��o do gerador de frames";
				gera_testbench();
				cout << endl << "FINALIZANDO :: Testbench para simula��o do gerador de frames gerado";
				cout << endl << "FINALIZANDO :: Gerando script para simula��o do gerador de frames";
				gera_script(qt_frames);
				cout << endl << "FINALIZANDO :: Script para simula��o do gerador de frames gerado";
			}

			// Insere o resto do sinal (o que nao completou de uma word)
			if(ALIGNMENT) insere_resto();

			// Fecha arquivos
			fecha_arquivos();

			// Imprime todas as opcoes escolhidas - Report
			report_geral();

			// Imprime a interface final e atualiza as vari�veis passadas por par�metro
			if(flagqf==0) {
				interface_final(&entrada,&continua);
			} else {
				continua = false;
			}
			
			// Incrementa quantidade de repeticoes feitas(frames gerados)
			repeticoes++;
		}else{
			cria_config();
			continua = false;
		}
		
		saida.close();
		
	}while(continua);

}

/********************************************************************************************
** Monta Frame OTN
*********************************************************************************************/

void build_frame(int i)
{
	cout << endl << endl << "FRAME " << setw(4) << setfill('0') << i;

	// Insere overheads
	cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Gerando overheads";
	insere_overheads(i);
	cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Overheads gerados";
	
	if(PRINT_AFTER==1) print_frame_graph(i);
	
	// Insere payload
	cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Gerando payload";
	if(TEST_SIGNAL){
		insere_null();
	}else{
		insere_prbs();
	}
	cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Payload gerado";
	
	if(PRINT_AFTER==2) print_frame_graph(i);
	
	// Insere FEC
	if(FEC){
		cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Gerando FEC";
		insere_fec();
		cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: FEC gerado";
	}
	
	if(PRINT_AFTER==3) print_frame_graph(i);
	
	// Insere erros
	if(NUMERRORS > 0){
		cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Gerando erros";
		gera_posicao_erros(NUMERRORS, TIPERRORS);
		cout << endl << "FRAME " << setw(4) << setfill('0') << i << " ::: Erros gerados";
	}
	
	if(PRINT_AFTER==4) print_frame_graph(i);
}
