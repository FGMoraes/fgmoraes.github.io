

	README
	
	Para rodar cada um dos casos de teste entre na pasta de simula��o.
	Dentro desta pasta contram-se as pastas de cada caso de teste.
	
	Os scripts que est�o situados em cada pasta de casos de teste devem ser 
	executados de onde est�o. Estes scripts referenciam os VHDLs do projeto e 
	de testbench que est�o em um diret�rio em um nivel mais acima.
	