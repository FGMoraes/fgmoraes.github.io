/*
 * Copyright (c) 2005-2021 Imperas Software Ltd., www.imperas.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied.
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */


////////////////////////////////////////////////////////////////////////////////
//
//                W R I T T E N   B Y   I M P E R A S   I G E N
//
//                             Version 20210408.0
//
////////////////////////////////////////////////////////////////////////////////

#define UNUSED   __attribute__((unused))

// instantiate module components
static OP_CONSTRUCT_FN(instantiateComponents) {



    // Bus bus0

    optBusP bus0_b = opBusNew(mi, "bus0", 32, 0, 0);


    // Bus bus1

    optBusP bus1_b = opBusNew(mi, "bus1", 32, 0, 0);


    // Bus busShare

    optBusP busShare_b = opBusNew(mi, "busShare", 32, 0, 0);


    // Processor P0

    const char *P0_path = opVLNVString(
        0, // use the default VLNV path
        "riscv.ovpworld.org",
        "processor",
        "riscv",
        "1.0",
        OP_PROCESSOR,
        1   // report errors
    );

    optProcessorP P0_c = opProcessorNew(
        mi,
        P0_path,
        "P0",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus0_b, "INSTRUCTION"),
                OP_BUS_CONNECT(bus0_b, "DATA")
            )
        ),
        OP_PARAMS(
             OP_PARAM_BOOL_SET("simulateexceptions", 1)
            ,OP_PARAM_ENUM_SET("variant", "RVB32I")
            ,OP_PARAM_STRING_SET("add_Extensions", "MSU")
        )
    );

    const char *riscv32Newlib_0_expath = opVLNVString(
        0, // use the default VLNV path
        0,
        0,
        "riscv32Newlib",
        0,
        OP_EXTENSION,
        1   // report errors
    );

    opProcessorExtensionNew(
        P0_c,
        riscv32Newlib_0_expath,
        "riscv32Newlib_0_ex",
        0
    );

    // Processor P1

    const char *P1_path = opVLNVString(
        0, // use the default VLNV path
        "riscv.ovpworld.org",
        "processor",
        "riscv",
        "1.0",
        OP_PROCESSOR,
        1   // report errors
    );

    optProcessorP P1_c = opProcessorNew(
        mi,
        P1_path,
        "P1",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus1_b, "INSTRUCTION"),
                OP_BUS_CONNECT(bus1_b, "DATA")
            )
        ),
        OP_PARAMS(
             OP_PARAM_BOOL_SET("simulateexceptions", 1)
            ,OP_PARAM_UNS32_SET("cpuid", 1)
            ,OP_PARAM_ENUM_SET("variant", "RVB32I")
            ,OP_PARAM_STRING_SET("add_Extensions", "MSU")
        )
    );

    const char *riscv32Newlib_1_expath = opVLNVString(
        0, // use the default VLNV path
        0,
        0,
        "riscv32Newlib",
        0,
        OP_EXTENSION,
        1   // report errors
    );

    opProcessorExtensionNew(
        P1_c,
        riscv32Newlib_1_expath,
        "riscv32Newlib_1_ex",
        0
    );

    // Memory localLow0

    opMemoryNew(
        mi,
        "localLow0",
        OP_PRIV_RWX,
        (0x10ffffffULL) - (0x0ULL),
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus0_b, "sp1", .slave=1, .addrLo=0x0ULL, .addrHi=0x10ffffffULL)
            )
        ),
        0
    );

    // Memory localHigh0

    opMemoryNew(
        mi,
        "localHigh0",
        OP_PRIV_RWX,
        (0xffffffffULL) - (0x90000000ULL),
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus0_b, "sp1", .slave=1, .addrLo=0x90000000ULL, .addrHi=0xffffffffULL)
            )
        ),
        0
    );

    // Memory localLow1

    opMemoryNew(
        mi,
        "localLow1",
        OP_PRIV_RWX,
        (0x10ffffffULL) - (0x0ULL),
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus1_b, "sp1", .slave=1, .addrLo=0x0ULL, .addrHi=0x10ffffffULL)
            )
        ),
        0
    );

    // Memory localHigh1

    opMemoryNew(
        mi,
        "localHigh1",
        OP_PRIV_RWX,
        (0xffffffffULL) - (0x90000000ULL),
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus1_b, "sp1", .slave=1, .addrLo=0x90000000ULL, .addrHi=0xffffffffULL)
            )
        ),
        0
    );

    // Memory ramShared

    opMemoryNew(
        mi,
        "ramShared",
        OP_PRIV_RWX,
        (0xffffffULL) - (0x0ULL),
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(busShare_b, "sp1", .slave=1, .addrLo=0x0ULL, .addrHi=0xffffffULL)
            )
        ),
        0
    );

    // Bridge bridge0

    opBridgeNew(
        mi,
        "bridge0",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(busShare_b, "mp0", .addrLo=0x0ULL, .addrHi=0xffffffULL),
                OP_BUS_CONNECT(bus0_b, "sp1", .slave=1, .addrLo=0x11000000ULL, .addrHi=0x11ffffffULL)
            )
        ),
        0
    );

    // Bridge bridge1

    opBridgeNew(
        mi,
        "bridge1",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(busShare_b, "mp1", .addrLo=0x0ULL, .addrHi=0xffffffULL),
                OP_BUS_CONNECT(bus1_b, "sp1", .slave=1, .addrLo=0x11000000ULL, .addrHi=0x11ffffffULL)
            )
        ),
        0
    );

    // PSE checkSum0

    const char *checkSum0_path = "peripheral/pse.pse";
    opPeripheralNew(
        mi,
        checkSum0_path,
        "checkSum0",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus0_b, "MREAD"),
                OP_BUS_CONNECT(bus0_b, "DMAC", .slave=1, .addrLo=0x80000000ULL, .addrHi=0x8000000bULL)
            )
        ),
        0
    );

    // PSE checkSum1

    const char *checkSum1_path = "peripheral/pse.pse";
    opPeripheralNew(
        mi,
        checkSum1_path,
        "checkSum1",
        OP_CONNECTIONS(
            OP_BUS_CONNECTIONS(
                OP_BUS_CONNECT(bus1_b, "MREAD"),
                OP_BUS_CONNECT(bus1_b, "DMAC", .slave=1, .addrLo=0x80000000ULL, .addrHi=0x8000000bULL)
            )
        ),
        0
    );

}

optModuleAttr modelAttrs = {
    .versionString        = OP_VERSION,
    .type                 = OP_MODULE,
    .name                 = MODULE_NAME,
    .objectSize           = sizeof(optModuleObject),
    .releaseStatus        = OP_UNSET,
    .purpose              = OP_PP_BAREMETAL,
    .visibility           = OP_VISIBLE,
    .vlnv          = {
        .vendor  = "defaultVendor",
        .library = "work",
        .name    = "twoProcessorShared",
        .version = "1.0"
    },
    .constructCB          = moduleConstructor,
    .preSimulateCB        = modulePreSimulate,
    .simulateCB           = moduleSimulateStart,
    .postSimulateCB       = modulePostSimulate,
    .destructCB           = moduleDestruct,
};
