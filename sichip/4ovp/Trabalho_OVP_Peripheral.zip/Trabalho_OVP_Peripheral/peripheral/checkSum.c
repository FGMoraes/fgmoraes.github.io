
////////////////////////////////////////////////////////////////////////////////
//
//                W R I T T E N   B Y   I M P E R A S   I G E N
//
//                             Version 20210408.0
//
////////////////////////////////////////////////////////////////////////////////

#include "checkSum.igen.h"
#include <string.h>

// The buffer size
#define BUFFER_SIZE 16

// Finish flag
#define FINISH      0x50505050
#define WAITING     0x30303030

unsigned int address_to_check;

///////////////////////////////// Functions ////////////////////////////////////

// Reads a flit from a given address
char readMem(unsigned int addr){
    char buff;
    ppmAddressSpaceHandle h = ppmOpenAddressSpace("MREAD");
    if(!h) {
        bhmMessage("I", "checkSum", "ERROR READING MEMORY!");
        while(1){ } // error handling 
    }
    ppmReadAddressSpace(h, addr, sizeof(buff), &buff);
    ppmCloseAddressSpace(h);
    return buff;
}

#define __bswap_constant_32(x) \
     ((((x) & 0xff000000) >> 24) | (((x) & 0x00ff0000) >>  8) |		      \
      (((x) & 0x0000ff00) <<  8) | (((x) & 0x000000ff) << 24))

unsigned int htonl(unsigned int x){
    return x;//__bswap_constant_32(x);
}

//////////////////////////////// Callback stubs ////////////////////////////////

PPM_REG_READ_CB(address_R) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_RNB", "Only 4 byte access permitted");
        return 0;
    }
    // YOUR CODE HERE (address_R)
    return *(Uns32*)user;
}

PPM_REG_WRITE_CB(address_W) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_WNB", "Only 4 byte access permitted");
        return;
    }
    address_to_check = data; // the processor writes an address to check
    
    // check sum
    unsigned char sum = 0;
    char element = 0;
    int i;
    for( i = 0; i < BUFFER_SIZE; i++ ){
        element = readMem(address_to_check);
        address_to_check++;
        sum -= element;
    }

    // sets the memory mapped register with the value
    DMAC_ab_data.checkSum.value = (unsigned int)sum;

    // sets the completion flag
    DMAC_ab_data.statusCS.value = FINISH;

    *(Uns32*)user = data;
    // YOUR CODE HERE (address_W)
}

PPM_REG_READ_CB(checkSum_R) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_RNB", "Only 4 byte access permitted");
        return 0;
    }

    // unset the completion flag
    DMAC_ab_data.statusCS.value = WAITING;

    // YOUR CODE HERE (checkSum_R)
    return *(Uns32*)user;
}

PPM_REG_WRITE_CB(checkSum_W) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_WNB", "Only 4 byte access permitted");
        return;
    }
    *(Uns32*)user = data;
    // YOUR CODE HERE (checkSum_W)
}

PPM_REG_READ_CB(statusCS_R) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_RNB", "Only 4 byte access permitted");
        return 0;
    }
    // YOUR CODE HERE (statusCS_R)
    return *(Uns32*)user;
}

PPM_REG_WRITE_CB(statusCS_W) {
    if(bytes != 4) {
        bhmMessage("E", "PPM_WNB", "Only 4 byte access permitted");
        return;
    }
    *(Uns32*)user = data;
    // YOUR CODE HERE (statusCS_W)
}

PPM_CONSTRUCTOR_CB(constructor) {
    // YOUR CODE HERE (pre constructor)
    periphConstructor();
    // YOUR CODE HERE (post constructor)
}

PPM_DESTRUCTOR_CB(destructor) {
    // YOUR CODE HERE (destructor)
}


PPM_SAVE_STATE_FN(peripheralSaveState) {
    bhmMessage("E", "PPM_RSNI", "Model does not implement save/restore");
}

PPM_RESTORE_STATE_FN(peripheralRestoreState) {
    bhmMessage("E", "PPM_RSNI", "Model does not implement save/restore");
}


