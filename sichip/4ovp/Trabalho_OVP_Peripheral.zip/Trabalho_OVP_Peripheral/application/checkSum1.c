#include <stdio.h>
#include <stdlib.h>

#include "sharedData.h"
#include "math.h"
#include "simulatorIntercepts.h"

//
// Main routine
//
int main(int argc, char **argv) {

    ctrlP ctrl = CONTROL;
    FILE *fp_i;
    int reader_id = impProcessorId();
    int writer_id = reader_id + 1;
    static volatile char local_buffer[BUFFER_SIZE];
    int i, j, send;
    int fail = 21;

    // opens the file
    fp_i = fopen("application/input.txt", "r");
    if( fp_i == NULL ) {
        exit(0);
    }

    // main loop
    while((i = fread(local_buffer, 1, BUFFER_SIZE, fp_i)) > 0){

        /* clear the buffer if something remains there */ 
        if( i < BUFFER_SIZE){
            for(j = i; j < BUFFER_SIZE; j++){
                local_buffer[j] = '\0'; // Fill the remaining positions with NULL
            }
        }
        send = 1;

        while(send){

            *cs_address = &local_buffer[0]; // sends the local buffer addr to the peripheral

            while(*cs_status != FINISH){}  // waits the checkSum

            ctrl->processor_checkSum[reader_id] = *cs_checkSum; // updates the checkSum
            if(!(fail--)){ // add an failure in the checksum value...
                ctrl->processor_checkSum[reader_id]++;
            }

            for(i = 0; i < BUFFER_SIZE; i++){  // sends the buffer content
                ctrl->buffer[i] = local_buffer[i];
            }

            ctrl->processor_status[reader_id] = NEW_VALUE; // informs the other processor that exist a new buffer

            while(ctrl->processor_status[writer_id] != CHECKING){} // waits the other processor receive the buffer content

            ctrl->processor_status[reader_id] = WAITING; // informs that the reader is waiting for the result

            while(ctrl->processor_status[writer_id] != CHECKED){} // waits the other processor inform the calculated checkSum

            if( ctrl->processor_checkSum[reader_id] == ctrl->processor_checkSum[writer_id] ) send = 0;
            
            printf("Processor 0 found checkSum = %d\n", ctrl->processor_checkSum[reader_id]);
            printf("Processor 1 found checkSum = %d\n", ctrl->processor_checkSum[writer_id]);
            if( send ){
                printf("====>Sending failure, trying again...\n================\n");
            } else{ 
                printf("Sending success!\n================\n");
            }
        }

        if(feof(fp_i)){
            ctrl->processor_status[reader_id] = FINISH;
            printf(">>>>>> File transfered! <<<<<<\n");
            break;
        }
    }

    fclose(fp_i);
    return 0;
}
