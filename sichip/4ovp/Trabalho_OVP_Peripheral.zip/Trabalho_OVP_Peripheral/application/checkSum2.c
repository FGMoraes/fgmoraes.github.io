#include <stdio.h>
#include <stdlib.h>

#include "sharedData.h"
#include "math.h"
#include "simulatorIntercepts.h"

//
// Main routine
//
int main(int argc, char **argv) {

    ctrlP ctrl = CONTROL;
    FILE *fp_o;
    static volatile char local_buffer[BUFFER_SIZE];
    int writer_addr = impProcessorId();
    int reader_addr = writer_addr - 1;
    int i, j;

    // opens the file
    fp_o = fopen("application/output.txt", "w");
    if( fp_o == NULL ) {
        exit(0);
    }

    // main loop
    while(1){

        // Waits the reader to tell if the process is finished or it has a new buffer to write
        while( ctrl->processor_status[reader_addr] != FINISH && ctrl->processor_status[reader_addr] != NEW_VALUE ){}

        if( ctrl->processor_status[reader_addr] == FINISH ){ // if the reader has finished the file
            break;
        } else { // NEW_VALUE
            
            for( i = 0; i < BUFFER_SIZE; i++ ){ // copy the buffer to the local memory
                local_buffer[i] = ctrl->buffer[i];
            }

            ctrl->processor_status[writer_addr] = CHECKING; // informs the reader

            while(ctrl->processor_status[reader_addr] != WAITING){} // waits the ack from the reader

            *cs_address = &local_buffer[0]; // sends the local buffer addr to the peripheral

            while(*cs_status != FINISH){}  // waits the checkSum

            ctrl->processor_checkSum[writer_addr] = *cs_checkSum; // updates the checkSum

            if( ctrl->processor_checkSum[writer_addr] == ctrl->processor_checkSum[reader_addr] ){
                fwrite(ctrl->buffer, 1, BUFFER_SIZE, fp_o); // writes the buffer into the file
            }

            ctrl->processor_status[writer_addr] = CHECKED;

        }
    
    }

    fclose(fp_o);
    return 0;
}