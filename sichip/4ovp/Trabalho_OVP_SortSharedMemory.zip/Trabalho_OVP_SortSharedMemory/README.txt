Dentro da pasta "module" encontra-se um script para gerar um .tcl de um sistema de N processadores.
$ cd module
$ ./moduleGen.sh N

Para executar o sistema criado deve-se editar o script na pasta raiz, "example.sh", adicionando uma tarefa para cada processador criado, por exemplo, um sistema onde N = 4 temos a seguinte situação:
example.sh (linha 15)            --program twoProcessorShared/P0=application/encrypt.${CROSS}.elf \
example.sh (linha 16)            --program twoProcessorShared/P1=application/decrypt.${CROSS}.elf \
example.sh (linha 17)            --program twoProcessorShared/P2=application/task2.${CROSS}.elf \
example.sh (linha 18)            --program twoProcessorShared/P3=application/task3.${CROSS}.elf \

Essas tarefas devem ser compiladas. Para tal, basta que entre na pasta application e modifique o Makefile, inserindo os nomes dos arquivos que contem as tarefas criadas, por exemplo, para as tarefas utilizadas no exemplo anterior:
Makefile (linha 9)	     SRC?=encrypt.c decrypt.c task2.c task3.c
