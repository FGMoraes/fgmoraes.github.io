#!/bin/bash

# Check Installation supports this example
checkinstall.exe -p install.pkg --nobanner || exit

cd application
make clean
cd ../module
make clean
cd ..

CROSS=RISCV32IM

make -C application CROSS=${CROSS}

make -C harness

# generate and compile the iGen created module
make -C module NOVLNV=1

# run the module using the local C harness
harness/harness.${IMPERAS_ARCH}.exe --program application/fibonacci.${CROSS}.elf $*