========================================================================
     TUTORIAL OVP  - atualizado em 26/novembro/2021
		  Iaçanã Ianiski Weber
========================================================================

Definindo o ambiente, utilizando os três comandos abaixo:

	$ module load ovp/2021	

	$ source /soft64/imperas/ferramentas/Imperas.20210408/bin/setup.sh
	
	$ setupImperas /soft64/imperas/ferramentas/Imperas.20210408
======================================================================== 
Obtendo os exemplos:
  
	$ wget http://www.inf.pucrs.br/~moraes/ovp2021.tar.gz
========================================================================
Descompactando: 

	$ tar -xzvf ovp2021.tar.gz
========================================================================

Principais arquivos de documentação do OVP no diretorio "doc". Documentação adicional em http://www.ovpworld.org/documentation. 

========================================================================
1. Trabalhando com o primeiro exemplo - Open RISC 1000 (OR1K)
========================================================================
	$ cd ovp_2021/1_OVP_OR1K

 - Inicialmente, vamos compilar as aplicações:
	$ cd applications
	$ make clean
	$ make all
	
 - Depois de compilar, voltamos ao diretório inicial:
	$ cd ..

 - Simular cada aplicação na plataforma gerada:
        $ ./RUN_linpack.sh
	$ ./RUN_peakSpeed2.sh
       	$ ./RUN_dhrystone.sh
	$ ./RUN_fibonacci.sh

 - No final de cada simulação, são geradas estatísticas.

========================================================================
2. Trabalhando com o segundo exemplo - ARM (ARM920T)
========================================================================
	$ cd ovp_2021/2_OVP_ARM920T

 - Inicialmente, vamos compilar as aplicações:
	$ cd applications
	$ make clean
	$ make all
	
 - Depois de compilar, voltamos ao diretório inicial:
	$ cd ..

 - Simular cada aplicação na plataforma gerada:
        $ ./RUN_linpack.sh
	$ ./RUN_peakSpeed2.sh
       	$ ./RUN_dhrystone.sh
	$ ./RUN_fibonacci.sh

 - No final de cada simulação, são geradas estatísticas.

========================================================================
3. Trabalhando com o terceiro exemplo - Dois processadores ARM (ARM920T)
========================================================================
	$ cd ovp_2021/3_OVP_ARM_DualCore

 - Inicialmente, vamos compilar as aplicações:
	$ cd applications
	$ make clean
	$ make all
	
 - Depois de compilar, voltamos ao diretório inicial:
	$ cd ..

 - Simular a aplicação:
        $ ./RUN_MultiCore2.sh

 - No final de cada simulação, são geradas estatísticas.

========================================================================
4. Trabalhando com o quarto exemplo - iGen - Gerando uma Plataforma
========================================================================
	$ cd ovp_2021/4_OVP_iGen_HelloWorld

 - Simular a plataforma:
	$ ./example.sh

========================================================================
5. Trabalhando com o quinto exemplo - Gerando plataforma com periférico
========================================================================
	$ cd ovp_2021/5_OVP_iGen_UART

 - Simular a plataforma:
	$ ./example.sh

========================================================================
6. Trabalhando com o sexto exemplo - Gerando plataforma multicore com memória compartilhada
========================================================================
	$ cd ovp_2021/6_OVP_DualCore_SharedMemory

 - Simular a plataforma:
	$ ./example.sh

========================================================================
7. Trabalhando com o sétimo exemplo - Harness customizado
========================================================================
	$ cd ovp_2021/7_OVP_Custom_Harness

 - Simular a plataforma:
	$ ./example.sh
	
 - Atividade: Descobrir quantas vezes a função fib() é chamada durante a execução do programa.
 	1 - Solução via software:
 		 - Criar uma variável global e dentro da função fib() incrementar.
 		 - Ao final, printar a variável global.
 		Na aplicação (application/application.c) modificar o valor do define TRACE_FIB para 1
 ------------------------------------------------------------------------
 	2 - Solução via harness:
 		 - Descobrir em qual posição da memória a função fib() começa...
 		     -> dentro da pasta application execute: $ or32-elf-objdump -d application.OR1K.elf >> application.S
 		 - Sabendo a posição da memória, vamos adicionar um monitor de fetch no harness, desta forma sabemos exatamente quantas vezes o processador buscou aquela posição de memória e, por consequencia, quantas vezes a função foi evocada.
 		No harness (harness/harness.c) modificar o valor do define TRACE_FIB para 1

#########################################################################
#########################################################################
  	A R Q U I V O S     N A    D I S T R I B U I Ç Ã O
#########################################################################
#########################################################################

ovp_2021
├── 1_OVP_OR1K
│   ├── applications
│   │   ├── dhrystone
│   │   │   ├── dhrystone.c
│   │   │   └── Makefile
│   │   ├── fibonacci
│   │   │   ├── fibonacci.c
│   │   │   └── Makefile
│   │   ├── linpack
│   │   │   ├── linpack.c
│   │   │   └── Makefile
│   │   ├── Makefile
│   │   └── peakSpeed2
│   │       ├── Makefile
│   │       └── peakSpeed2.c
│   ├── imperas.log
│   ├── README.html
│   ├── Run_Dhrystone.sh
│   ├── Run_Fibonacci.sh
│   ├── Run_Linpack.sh
│   └── Run_PeakSpeed2.sh
├── 2_OVP_ARM920T
│   ├── applications
│   │   ├── dhrystone
│   │   │   ├── dhrystone.c
│   │   │   └── Makefile
│   │   ├── fibonacci
│   │   │   ├── fibonacci.c
│   │   │   └── Makefile
│   │   ├── linpack
│   │   │   ├── linpack.c
│   │   │   └── Makefile
│   │   ├── Makefile
│   │   └── peakSpeed2
│   │       ├── Makefile
│   │       └── peakSpeed2.c
│   ├── imperas.log
│   ├── Run_Dhrystone.sh
│   ├── Run_Fibonacci.sh
│   ├── Run_Linpack.sh
│   └── Run_PeakSpeed2.sh
├── 3_OVP_ARM_DualCore
│   ├── application
│   │   ├── Makefile
│   │   ├── multicore2_main.c
│   │   ├── multicore2_reader.c
│   │   └── multicore2_writer.c
│   ├── imperas.log
│   └── Run_MultiCore2.sh
├── 4_OVP_iGen_HelloWorld
│   ├── application
│   │   ├── application.c
│   │   └── Makefile
│   ├── example.sh
│   ├── install.pkg
│   ├── module
│   │   ├── Makefile
│   │   ├── module.c
│   │   └── module.op.tcl
│   ├── README.txt
│   └── simpleCpuMemory.jpg
├── 5_OVP_iGen_UART
│   ├── application
│   │   ├── application.c
│   │   └── Makefile
│   ├── example.sh
│   ├── install.pkg
│   ├── module
│   │   ├── Makefile
│   │   ├── module.c
│   │   └── module.op.tcl
│   ├── README.txt
│   ├── simpleCpuMemoryUart.jpg
│   └── uartTTY0.log
├── 6_OVP_DualCore_SharedMemory
│   ├── application
│   │   ├── constitution.txt
│   │   ├── decrypt.c
│   │   ├── encrypt.c
│   │   ├── Makefile
│   │   ├── sharedData.h
│   │   └── shared.h
│   ├── example.sh
│   ├── install.pkg
│   ├── module
│   │   ├── Makefile
│   │   ├── model.so
│   │   ├── module.c
│   │   ├── module.c.igen.stubs
│   │   ├── module.igen.h
│   │   ├── module.op.tcl
│   │   └── obj
│   │       └── Linux64
│   │           ├── module.d
│   │           └── module.o
│   ├── README.txt
│   └── twoProcessor.jpg
├── 7_OVP_Custom_Harness
│   ├── application
│   │   ├── application.c
│   │   └── Makefile
│   ├── example.sh
│   ├── harness
│   │   ├── harness.c
│   │   └── Makefile
│   ├── install.pkg
│   ├── module
│   │   ├── Makefile
│   │   ├── module.c
│   │   └── module.op.tcl
│   └── README.txt
└── README.txt

