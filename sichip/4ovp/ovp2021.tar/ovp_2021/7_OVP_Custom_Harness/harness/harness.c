/*
 *
 * Copyright (c) 2005-2021 Imperas Software Ltd., www.imperas.com
 *
 * The contents of this file are provided under the Software License
 * Agreement that you accepted before downloading this file.
 *
 * This source forms part of the Software and can be used for educational,
 * training, and demonstration purposes but cannot be used for derivative
 * works except in cases where the derivative works require OVP technology
 * to run.
 *
 * For open source models released under licenses that you can use for
 * derivative works, please visit www.OVPworld.org or www.imperas.com
 * for the location of the open source models.
 *
 */

#include <string.h>
#include <stdlib.h>

#include "op/op.h"

#define TRACE_FIB 0

#define MODULE_NAME "top"
#define MODULE_DIR "module"
#define MODULE_INSTANCE "u2"

unsigned int trace_fib = 0;

struct optionsS {
} options = {
};

static OP_CONSTRUCT_FN(moduleConstruct) {
    const char *u1_path = "module";
    opModuleNew(
        mi,       // parent module
        u1_path,       // modelfile
        "u1",   // name
        0,
        0
    );
}

static void cmdParser(optCmdParserP parser) {
}

typedef struct optModuleObjectS {
    // insert module persistent data here
} optModuleObject;

static OP_PRE_SIMULATE_FN(modulePreSimulate) {
// insert modulePreSimulate code here
}

static OP_SIMULATE_STARTING_FN(moduleSimulate) {
// insert moduleSimulate code here
}

static OP_POST_SIMULATE_FN(modulePostSimulate) {
// insert modulePostSimulate code here
}

static OP_DESTRUCT_FN(moduleDestruct) {
// insert moduleDestruct code here
}

optModuleAttr modelAttrs = {
    .versionString       = OP_VERSION,
    .type                = OP_MODULE,
    .name                = MODULE_NAME,
    .objectSize          = sizeof(optModuleObject),
    .releaseStatus       = OP_UNSET,
    .purpose             = OP_PP_BAREMETAL,
    .visibility          = OP_VISIBLE,
    .constructCB          = moduleConstruct,
    .preSimulateCB        = modulePreSimulate,
    .simulateCB           = moduleSimulate,
    .postSimulateCB       = modulePostSimulate,
    .destructCB           = moduleDestruct,
};

#if TRACE_FIB
static OP_MONITOR_FN(fib_fetch_CB) { 
    trace_fib++;
    return;
}
#endif

int main(int argc, const char *argv[]) {
    opSessionInit(OP_VERSION);
    optCmdParserP parser = opCmdParserNew(MODULE_NAME, OP_AC_ALL);
    cmdParser(parser);
    opCmdParseArgs(parser, argc, argv);
#if TRACE_FIB
    optModuleP  mi     = opRootModuleNew(0, 0, 0);
    optModuleP  ui     = opModuleNew(mi, MODULE_DIR, MODULE_INSTANCE, 0, 0);
	
    // gets the processor
    optProcessorP proc = opProcessorNext(ui, NULL);
    
    // pre simulate 
    opRootModulePreSimulate(mi);
    
    // add a fetch monitor to the processor
    opProcessorFetchMonitorAdd(proc, 0x0f2c, 0x0f2c, fib_fetch_CB, "fib_trace");
    
    // Simulate the loaded module
    opRootModuleSimulate(mi);
    opMessage("I", "Harness", "fib(int i) was called: %d times", trace_fib);
#else
    optModuleP mi = opRootModuleNew(&modelAttrs, MODULE_NAME, 0);
    opRootModuleSimulate(mi);
#endif
    opSessionTerminate();
    
    return (opErrors() ? 1 : 0);    // set exit based upon any errors
}

