#!/bin/bash
# Run_Fibonacci.sh

${IMPERAS_ISS} --verbose --output imperas.log \
    --program applications/fibonacci/fibonacci.ARM9T-O3-g.elf \
    --processorvendor arm.ovpworld.org --processorname arm --variant ARM920T \
    --numprocessors 1     \
    --parameter compatibility=nopSVC --parameter UAL=1 --parameter endian=little  \
    "$@" \
    -argv 40

