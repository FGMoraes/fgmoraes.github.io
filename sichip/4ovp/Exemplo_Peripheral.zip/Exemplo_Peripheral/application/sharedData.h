/*
 *
 * Copyright (c) 2005-2021 Imperas Software Ltd., www.imperas.com
 *
 * The contents of this file are provided under the Software License
 * Agreement that you accepted before downloading this file.
 *
 * This source forms part of the Software and can be used for educational,
 * training, and demonstration purposes but cannot be used for derivative
 * works except in cases where the derivative works require OVP technology
 * to run.
 *
 * For open source models released under licenses that you can use for
 * derivative works, please visit www.OVPworld.org or www.imperas.com
 * for the location of the open source models.
 *
 */

#ifndef SHARED_DATA_H
#define SHARED_DATA_H

#include "shared.h"

// the size of the vector that must be sorted
#define BUFFER_SIZE 16

// the system size
#define SYSTEM_SIZE 2

// macros
#define NEW_VALUE   0x10101010
#define CHECKING    0x20202020
#define WAITING     0x30303030
#define CHECKED     0x40404040
#define FINISH      0x50505050

// defines the memory mapped registers
volatile unsigned int *cs_address   = CHECKSUM_BASE + 0x0;
volatile unsigned int *cs_status    = CHECKSUM_BASE + 0x1;
volatile unsigned int *cs_checkSum  = CHECKSUM_BASE + 0x2;

typedef struct ctrlS {
    // stores the vector itself
    char buffer[BUFFER_SIZE]; 
    // informs the processor status
    volatile int processor_status[SYSTEM_SIZE];
    // informs the processor checkSum
    volatile int processor_checkSum[SYSTEM_SIZE];
} ctrl, *ctrlP;

// pointer to the struct that controls the system
#define CONTROL ((ctrlP)(SHARED_LOW+0))

#endif
